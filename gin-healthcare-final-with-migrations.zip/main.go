
package main

import (
 "gin-healthcare-final-with-migrations/config"
 "gin-healthcare-final-with-migrations/controller"
 "gin-healthcare-final-with-migrations/pkg/db"
 "gin-healthcare-final-with-migrations/repository"
 "github.com/gin-gonic/gin"
)

func main() {
 db.RunMigrations(config.DBURL())

 pool := db.Connect()
 repo := &repository.Repository{DB: pool}
 ctrl := &controller.Controller{Repo: repo}

 r := gin.Default()
 v1 := r.Group("/api/v1")
 ctrl.Routes(v1)

 r.Run(":8080")
}
