
package config

type DBConfig struct {
 Host string
 Port string
 User string
 Password string
 Name string
}

func LoadDB() DBConfig {
 return DBConfig{
  Host: "localhost",
  Port: "5432",
  User: "root",
  Password: "root",
  Name: "patientdb01",
 }
}

func DBURL() string {
 cfg := LoadDB()
 return "postgres://" + cfg.User + ":" + cfg.Password +
  "@" + cfg.Host + ":" + cfg.Port + "/" + cfg.Name + "?sslmode=disable"
}
