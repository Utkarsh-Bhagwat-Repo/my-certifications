
package controller

import (
 "net/http"
 "strconv"
 "gin-healthcare-final-with-migrations/models"
 "gin-healthcare-final-with-migrations/repository"
 "github.com/gin-gonic/gin"
)

type Controller struct {
 Repo *repository.Repository
}

func (c *Controller) Routes(r *gin.RouterGroup) {
 r.POST("/patients", c.CreatePatient)
}

func (c *Controller) CreatePatient(ctx *gin.Context) {
 var p models.Patient
 if err := ctx.ShouldBindJSON(&p); err != nil {
  ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
  return
 }
 c.Repo.CreatePatient(&p)
 ctx.JSON(http.StatusCreated, p)
}
