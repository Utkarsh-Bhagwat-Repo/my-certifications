
package repository

import (
 "context"
 "gin-healthcare-final-with-migrations/models"
 "github.com/jackc/pgx/v5/pgxpool"
)

type Repository struct {
 DB *pgxpool.Pool
}

func (r *Repository) CreatePatient(p *models.Patient) error {
 return r.DB.QueryRow(context.Background(),
  "INSERT INTO patients(name,age) VALUES($1,$2) RETURNING id",
  p.Name, p.Age,
 ).Scan(&p.ID)
}
