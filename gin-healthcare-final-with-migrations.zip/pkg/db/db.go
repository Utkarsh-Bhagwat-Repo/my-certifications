
package db

import (
 "context"
 "fmt"
 "github.com/jackc/pgx/v5/pgxpool"
 "gin-healthcare-final-with-migrations/config"
)

func Connect() *pgxpool.Pool {
 cfg := config.LoadDB()
 dsn := fmt.Sprintf("postgres://%s:%s@%s:%s/%s",
  cfg.User, cfg.Password, cfg.Host, cfg.Port, cfg.Name,
 )
 pool, err := pgxpool.New(context.Background(), dsn)
 if err != nil {
  panic(err)
 }
 return pool
}
