
package models

type Patient struct {
 ID int `json:"id"`
 Name string `json:"name"`
 Age int `json:"age"`
}

type Lab struct {
 ID int `json:"id"`
 PatientID int `json:"patient_id"`
 LabName string `json:"lab_name"`
 LabResult string `json:"lab_result"`
}

type Encounter struct {
 ID int `json:"id"`
 PatientID int `json:"patient_id"`
 Date string `json:"date"`
 Notes string `json:"notes"`
}

type Medication struct {
 ID int `json:"id"`
 PatientID int `json:"patient_id"`
 Name string `json:"name"`
 Dosage string `json:"dosage"`
}
