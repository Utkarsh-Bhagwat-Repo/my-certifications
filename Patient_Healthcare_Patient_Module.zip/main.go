package main

import (
 "log"

 "github.com/gin-gonic/gin"
 "go.uber.org/zap"

 "patient-healthcare-demo/config"
 "patient-healthcare-demo/db"
 "patient-healthcare-demo/middleware"
 "patient-healthcare-demo/router"
)

func main() {
 cfg := config.Load()

 logger, _ := zap.NewProduction()
 defer logger.Sync()

 pool, err := db.Connect(cfg.DBURL)
 if err != nil {
  log.Fatal(err)
 }

 r := gin.New()
 r.Use(middleware.Logger(logger))
 r.Use(gin.Recovery())

 router.RegisterPatientRoutes(r, pool, logger)

 logger.Info("Server started", zap.String("port", cfg.Port))
 r.Run(cfg.Port)
}
