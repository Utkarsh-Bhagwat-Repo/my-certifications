package config

type Config struct {
 DBURL string
 Port  string
}

func Load() *Config {
 return &Config{
  DBURL: "postgres://postgres:postgres@localhost:5432/PatientDB02?sslmode=disable",
  Port:  ":8080",
 }
}
