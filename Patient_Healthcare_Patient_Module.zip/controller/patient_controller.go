package controller

import (
 "net/http"
 "strconv"

 "github.com/gin-gonic/gin"
 "go.uber.org/zap"

 "patient-healthcare-demo/handler"
 "patient-healthcare-demo/models"
)

type PatientController struct {
 Handler *handler.PatientHandler
 Log     *zap.Logger
}

func (c *PatientController) Create(ctx *gin.Context) {
 var p models.Patient
 if err := ctx.ShouldBindJSON(&p); err != nil {
  ctx.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
  return
 }
 _ = c.Handler.Create(&p)
 c.Log.Info("patient created", zap.Int("id", p.ID))
 ctx.JSON(http.StatusCreated, p)
}

func (c *PatientController) GetByID(ctx *gin.Context) {
 id, _ := strconv.Atoi(ctx.Param("id"))
 p, err := c.Handler.Get(id)
 if err != nil {
  ctx.JSON(http.StatusNotFound, gin.H{"error": "not found"})
  return
 }
 ctx.JSON(http.StatusOK, p)
}
