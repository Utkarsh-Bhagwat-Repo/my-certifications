package handler

import (
 "patient-healthcare-demo/models"
 "patient-healthcare-demo/repository"
)

type PatientHandler struct {
 Repo *repository.PatientRepository
}

func (h *PatientHandler) Create(p *models.Patient) error {
 return h.Repo.Create(p)
}

func (h *PatientHandler) Get(id int) (*models.Patient, error) {
 return h.Repo.GetByID(id)
}
