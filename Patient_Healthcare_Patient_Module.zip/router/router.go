package router

import (
 "github.com/gin-gonic/gin"
 "github.com/jackc/pgx/v5/pgxpool"
 "go.uber.org/zap"

 "patient-healthcare-demo/controller"
 "patient-healthcare-demo/handler"
 "patient-healthcare-demo/repository"
)

func RegisterPatientRoutes(r *gin.Engine, db *pgxpool.Pool, log *zap.Logger) {
 repo := &repository.PatientRepository{DB: db}
 h := &handler.PatientHandler{Repo: repo}
 c := &controller.PatientController{Handler: h, Log: log}

 v1 := r.Group("/api/v1")
 v1.POST("/patients", c.Create)
 v1.GET("/patients/:id", c.GetByID)
}
