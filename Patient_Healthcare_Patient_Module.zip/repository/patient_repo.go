package repository

import (
 "context"

 "github.com/jackc/pgx/v5/pgxpool"
 "patient-healthcare-demo/models"
)

type PatientRepository struct {
 DB *pgxpool.Pool
}

func (r *PatientRepository) Create(p *models.Patient) error {
 return r.DB.QueryRow(context.Background(),
  "INSERT INTO patients(name, age) VALUES($1,$2) RETURNING id",
  p.Name, p.Age).Scan(&p.ID)
}

func (r *PatientRepository) GetByID(id int) (*models.Patient, error) {
 p := &models.Patient{}
 err := r.DB.QueryRow(context.Background(),
  "SELECT id,name,age FROM patients WHERE id=$1",
  id).Scan(&p.ID, &p.Name, &p.Age)
 return p, err
}
