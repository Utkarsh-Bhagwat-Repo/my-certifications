package com.healthtrack360.dto;

import com.healthtrack360.domain.Patient;
import java.time.LocalDate;

public class PatientResponse {
    private Long id;
    private String patientCode;
    private String givenName;
    private String familyName;
    private String gender;
    private LocalDate dateOfBirth;
    private String addressLine1;
    private String addressLine2;
    private String country;
    private String state;
    private String city;
    private String zip;
    private String phoneNumber;
    private String email;

    public PatientResponse() {}

    public static PatientResponse from(Patient p) {
        PatientResponse r = new PatientResponse();
        r.id = p.getId();
        r.patientCode = p.getPatientCode();
        r.givenName = p.getGivenName();
        r.familyName = p.getFamilyName();
        r.gender = p.getGender() != null ? p.getGender().name() : null;
        r.dateOfBirth = p.getDateOfBirth();
        r.addressLine1 = p.getAddressLine1();
        r.addressLine2 = p.getAddressLine2();
        r.country = p.getCountry();
        r.state = p.getState();
        r.city = p.getCity();
        r.zip = p.getZip();
        r.phoneNumber = p.getPhoneNumber();
        if (p.getUser() != null) {
            r.email = p.getUser().getEmail();
        }
        return r;
    }

    // getters and setters
    public Long getId() { return this.id; }

    public void setId(Long id) { this.id = id; }

    public String getPatientCode() { return this.patientCode; }

    public void setPatientCode(String patientCode) { this.patientCode = patientCode; }

    public String getGivenName() { return this.givenName; }

    public void setGivenName(String givenName) { this.givenName = givenName; }

    public String getFamilyName() { return this.familyName; }

    public void setFamilyName(String familyName) { this.familyName = familyName; }

    public String getGender() { return this.gender; }

    public void setGender(String gender) { this.gender = gender; }

    public LocalDate getDateOfBirth() { return this.dateOfBirth; }

    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public String getAddressLine1() { return this.addressLine1; }

    public void setAddressLine1(String addressLine1) { this.addressLine1 = addressLine1; }

    public String getAddressLine2() { return this.addressLine2; }

    public void setAddressLine2(String addressLine2) { this.addressLine2 = addressLine2; }

    public String getCountry() { return this.country; }

    public void setCountry(String country) { this.country = country; }

    public String getState() { return this.state; }

    public void setState(String state) { this.state = state; }

    public String getCity() { return this.city; }

    public void setCity(String city) { this.city = city; }

    public String getZip() { return this.zip; }

    public void setZip(String zip) { this.zip = zip; }

    public String getPhoneNumber() { return this.phoneNumber; }

    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getEmail() { return this.email; }

    public void setEmail(String email) { this.email = email; }
}
