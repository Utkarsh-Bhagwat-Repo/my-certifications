
package store

import (
	"errors"
	"strings"
	"sync"

	"patientcrud/models"
)

// patients holds in-memory patient data (slice based storage)
var (
	patients []models.Patient
	mutex    sync.Mutex
	nextID   = 1
)

// init loads default data when application starts
func init() {
	Add(models.Patient{Name: "Amit", Age: 30})
	Add(models.Patient{Name: "Chinmay", Age: 28})
	Add(models.Patient{Name: "Karan", Age: 26})
	Add(models.Patient{Name: "Utkarsh", Age: 25})
}

// GetAll returns all patients
func GetAll() []models.Patient {
	return patients
}

// GetByID returns patient by ID
func GetByID(id int) (*models.Patient, error) {
	for _, p := range patients {
		if p.ID == id {
			return &p, nil
		}
	}
	return nil, errors.New("patient not found")
}

// Add inserts new patient
func Add(p models.Patient) models.Patient {
	mutex.Lock()
	defer mutex.Unlock()

	p.ID = nextID
	nextID++
	patients = append(patients, p)
	return p
}

// Update updates patient by ID
func Update(id int, updated models.Patient) error {
	for i, p := range patients {
		if p.ID == id {
			patients[i].Name = updated.Name
			patients[i].Age = updated.Age
			return nil
		}
	}
	return errors.New("patient not found")
}

// Delete deletes patient by ID
func Delete(id int) error {
	for i, p := range patients {
		if p.ID == id {
			patients = append(patients[:i], patients[i+1:]...)
			return nil
		}
	}
	return errors.New("patient not found")
}

// DeleteAll removes all patients
func DeleteAll() {
	patients = []models.Patient{}
}

// SearchByName searches patients by name (case-insensitive)
func SearchByName(name string) []models.Patient {
	result := []models.Patient{}
	for _, p := range patients {
		if strings.Contains(strings.ToLower(p.Name), strings.ToLower(name)) {
			result = append(result, p)
		}
	}
	return result
}

// SearchByAge searches patients by age
func SearchByAge(age float64) []models.Patient {
	result := []models.Patient{}
	for _, p := range patients {
		if p.Age == age {
			result = append(result, p)
		}
	}
	return result
}
