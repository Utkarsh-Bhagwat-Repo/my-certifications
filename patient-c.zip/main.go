
package main

import (
	"log"
	"net/http"

	_ "patientcrud/docs" // swagger generated docs
	"patientcrud/routes"

	httpSwagger "github.com/swaggo/http-swagger"
)

// main is the application entry point.
// It starts the HTTP server and registers routes.
func main() {

	// Register all application routes
	mux := routes.RegisterRoutes()

	// Register Swagger UI endpoint
	mux.Handle("/swagger/", httpSwagger.WrapHandler)

	log.Println("Server running on http://localhost:8080")
	log.Println("Swagger UI available at http://localhost:8080/swagger/index.html")

	// http.ListenAndServe starts an HTTP server on given port
	// mux is an HTTP request multiplexer (router)
	log.Fatal(http.ListenAndServe(":8080", mux))
}
