
package docs

// This folder is placeholder.
// Run `swag init` to regenerate swagger files.
