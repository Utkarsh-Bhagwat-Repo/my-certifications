
package handlers

import (
	"encoding/json"
	"net/http"
	"strconv"

	"patientcrud/models"
	"patientcrud/store"
)

// respondJSON sends JSON response
func respondJSON(w http.ResponseWriter, status int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(payload)
}

// GetAllPatients godoc
// @Summary Get all patients
// @Tags Patients
// @Produce json
// @Success 200 {array} models.Patient
// @Router /patients [get]
func GetAllPatients(w http.ResponseWriter, r *http.Request) {
	respondJSON(w, http.StatusOK, store.GetAll())
}

// AddPatient godoc
// @Summary Add new patient
// @Tags Patients
// @Accept json
// @Produce json
// @Router /add [post]
func AddPatient(w http.ResponseWriter, r *http.Request) {
	var p models.Patient
	json.NewDecoder(r.Body).Decode(&p)

	if p.Name == "" || p.Age <= 0 {
		respondJSON(w, http.StatusBadRequest, "invalid input")
		return
	}

	respondJSON(w, http.StatusCreated, store.Add(p))
}

// SearchPatientByName godoc
// @Summary Search patient by name
// @Tags Search
// @Router /search/name [get]
func SearchPatientByName(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	respondJSON(w, http.StatusOK, store.SearchByName(name))
}

// SearchPatientByAge godoc
// @Summary Search patient by age
// @Tags Search
// @Router /search/age [get]
func SearchPatientByAge(w http.ResponseWriter, r *http.Request) {
	age, _ := strconv.ParseFloat(r.URL.Query().Get("age"), 64)
	respondJSON(w, http.StatusOK, store.SearchByAge(age))
}
