
package routes

import (
	"net/http"

	"patientcrud/handlers"
)

// RegisterRoutes creates http.ServeMux
// ServeMux is an HTTP request router that matches URL paths
func RegisterRoutes() *http.ServeMux {

	mux := http.NewServeMux()

	mux.HandleFunc("/patients", handlers.GetAllPatients)
	mux.HandleFunc("/add", handlers.AddPatient)
	mux.HandleFunc("/search/name", handlers.SearchPatientByName)
	mux.HandleFunc("/search/age", handlers.SearchPatientByAge)

	return mux
}
