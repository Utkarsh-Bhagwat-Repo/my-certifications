export const environment = {
  production: true,
  apiBaseUrl: 'https://your-production-backend-url/api'
};
