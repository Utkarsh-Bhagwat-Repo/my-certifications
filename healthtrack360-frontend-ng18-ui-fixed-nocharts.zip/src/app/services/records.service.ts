import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { MedicalRecord } from '../core/models/record.models';

@Injectable({ providedIn: 'root' })
export class RecordsService {
  private baseUrl = `${environment.apiBaseUrl}/records`;

  constructor(private http: HttpClient) {}

  getMyRecords(): Observable<MedicalRecord[]> {
    return this.http.get<MedicalRecord[]>(`${this.baseUrl}/me`);
  }

  searchByPatientId(patientId: number): Observable<MedicalRecord[]> {
    const params = new HttpParams().set('patientId', patientId);
    return this.http.get<MedicalRecord[]>(this.baseUrl, { params });
  }

  addRecord(payload: { patientId: number; diagnosis: string; notes: string }): Observable<MedicalRecord> {
    return this.http.post<MedicalRecord>(this.baseUrl, payload);
  }
}
