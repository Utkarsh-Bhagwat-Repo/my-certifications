import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './static/about/about.component';
import { EmergencyComponent } from './static/emergency/emergency.component';
import { LocationsComponent } from './static/locations/locations.component';
import { AuthGuard } from './core/auth/auth.guard';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'emergency', component: EmergencyComponent },
  { path: 'locations', component: LocationsComponent },
  {
    path: 'auth',
    loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule)
  },
  {
    path: 'patient',
    canActivate: [AuthGuard],
    data: { roles: ['ROLE_PATIENT'] },
    loadChildren: () => import('./patient/patient.module').then(m => m.PatientModule)
  },
  {
    path: 'doctor',
    canActivate: [AuthGuard],
    data: { roles: ['ROLE_DOCTOR'] },
    loadChildren: () => import('./doctor/doctor.module').then(m => m.DoctorModule)
  },
  {
    path: 'admin',
    canActivate: [AuthGuard],
    data: { roles: ['ROLE_ADMIN'] },
    loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)
  },
  {
    path: 'appointments',
    canActivate: [AuthGuard],
    data: { roles: ['ROLE_PATIENT'] },
    loadChildren: () => import('./appointments/appointments.module').then(m => m.AppointmentsModule)
  },
  {
    path: 'records',
    canActivate: [AuthGuard],
    data: { roles: ['ROLE_PATIENT'] },
    loadChildren: () => import('./records/records.module').then(m => m.RecordsModule)
  },
  { path: '**', redirectTo: '' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
