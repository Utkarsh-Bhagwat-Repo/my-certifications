import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export type ToastType = 'success' | 'error';

export interface ToastMessage {
  type: ToastType;
  message: string;
  duration?: number;
}

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private readonly toastSubject = new Subject<ToastMessage>();
  readonly toasts$ = this.toastSubject.asObservable();

  success(message: string): void {
    this.toastSubject.next({ type: 'success', message, duration: 3000 });
  }

  error(message: string): void {
    this.toastSubject.next({ type: 'error', message, duration: 4000 });
  }
}
