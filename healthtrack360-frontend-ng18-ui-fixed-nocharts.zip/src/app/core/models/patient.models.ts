export interface PatientResponse {
  id: number;
  patientCode: string;
  givenName: string;
  familyName: string;
  gender: string;
  dateOfBirth: string;
  email: string;
  enabled: boolean;
}
