import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { RecordsRoutingModule } from './records-routing.module';
import { RecordsDashboardComponent } from './records-dashboard/records-dashboard.component';

@NgModule({
  declarations: [RecordsDashboardComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RecordsRoutingModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class RecordsModule {}
