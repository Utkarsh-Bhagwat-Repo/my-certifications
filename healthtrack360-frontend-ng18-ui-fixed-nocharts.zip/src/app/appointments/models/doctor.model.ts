
export interface Doctor {
  id: number;
  fullName: string;
  specialization: string;
  experienceYears: number;
  rating?: number;
  hospitalName?: string;
  city?: string;
  consultationFee?: number;
  availableDays?: string[]; // ['MONDAY','TUESDAY']
  availableSlots?: DoctorAvailabilitySlot[];
}

export interface DoctorAvailabilitySlot {
  dayOfWeek: string; // e.g. 'MONDAY'
  startTime: string; // '09:00'
  endTime: string;   // '12:00'
  slotDurationMinutes: number;
  remainingSlots?: number;
}
