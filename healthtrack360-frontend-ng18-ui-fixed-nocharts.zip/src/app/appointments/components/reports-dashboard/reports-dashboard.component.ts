import { Component, OnInit } from '@angular/core';
import {
  ReportingService,
  DailyAppointmentStats,
  SpecializationStats,
  DoctorUtilizationStats
} from '../../services/reporting.service';

@Component({
  selector: 'ht-reports-dashboard',
  templateUrl: './reports-dashboard.component.html',
  styleUrls: ['./reports-dashboard.component.scss']
})
export class ReportsDashboardComponent implements OnInit {

  fromDate!: string;
  toDate!: string;

  loading = false;

  daily: DailyAppointmentStats[] = [];
  specialization: SpecializationStats[] = [];
  utilization: DoctorUtilizationStats[] = [];

  constructor(private reporting: ReportingService) {}

  ngOnInit(): void {
    const today = new Date();
    const start = new Date();
    start.setDate(today.getDate() - 7);
    this.fromDate = start.toISOString().substring(0, 10);
    this.toDate = today.toISOString().substring(0, 10);
    this.load();
  }

  load(): void {
    if (!this.fromDate || !this.toDate) {
      return;
    }

    this.loading = true;

    this.reporting.getDailyStats(this.fromDate, this.toDate).subscribe({
      next: data => this.daily = data,
      error: () => {}
    });

    this.reporting.getSpecializationStats(this.fromDate, this.toDate).subscribe({
      next: data => this.specialization = data,
      error: () => {}
    });

    this.reporting.getDoctorUtilization(this.fromDate, this.toDate).subscribe({
      next: data => {
        this.utilization = data;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }
}
