import { Component, OnInit } from '@angular/core';
import { AppointmentsService } from '../../services/appointments.service';
import { Appointment } from '../../models/appointment.model';
import { NotificationService } from '../../../core/notification/notification.service';

@Component({
  selector: 'ht-patient-my-appointments',
  templateUrl: './patient-my-appointments.component.html',
  styleUrls: ['./patient-my-appointments.component.scss']
})
export class PatientMyAppointmentsComponent implements OnInit {

  appointments: Appointment[] = [];
  loading = false;

  editingAppointment: Appointment | null = null;
  newConcern: string = '';

  constructor(
    private appointmentsService: AppointmentsService,
    private notifications: NotificationService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.appointmentsService.getMyAppointments().subscribe({
      next: res => {
        this.appointments = res;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.notifications.error('Unable to load your appointments.');
      }
    });
  }

  openEdit(appt: Appointment): void {
    this.editingAppointment = appt;
    this.newConcern = '';
  }

  cancelEdit(): void {
    this.editingAppointment = null;
    this.newConcern = '';
  }

  save(): void {
    if (!this.editingAppointment) {
      return;
    }
    if (!this.newConcern) {
      this.notifications.error('Please enter your updated concern.');
      return;
    }

    this.appointmentsService.updateAppointment(this.editingAppointment.id, { concern: this.newConcern }).subscribe({
      next: () => {
        this.notifications.success('Appointment updated successfully.');
        this.editingAppointment = null;
        this.load();
      },
      error: () => {
        this.notifications.error('Failed to update appointment.');
      }
    });
  }

  cancelAppointment(appt: Appointment): void {
    if (!confirm('Are you sure you want to cancel this appointment?')) {
      return;
    }
    this.appointmentsService.cancelAppointment(appt.id).subscribe({
      next: () => {
        this.notifications.success('Appointment cancelled.');
        this.load();
      },
      error: () => {
        this.notifications.error('Failed to cancel appointment.');
      }
    });
  }
}
