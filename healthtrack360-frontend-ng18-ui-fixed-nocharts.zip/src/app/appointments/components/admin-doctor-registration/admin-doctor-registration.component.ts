import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DoctorsService } from '../../services/doctors.service';
import { NotificationService } from '../../../core/notification/notification.service';

@Component({
  selector: 'ht-admin-doctor-registration',
  templateUrl: './admin-doctor-registration.component.html',
  styleUrls: ['./admin-doctor-registration.component.scss']
})
export class AdminDoctorRegistrationComponent {

  form: FormGroup;
  submitting = false;

  specializations: string[] = ['Cardiologist', 'Dermatologist', 'Neurologist', 'Orthopedic', 'Pediatrician', 'General Physician'];
  cities: string[] = ['Mumbai', 'Pune', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai'];

  constructor(
    private fb: FormBuilder,
    private doctorsService: DoctorsService,
    private notifications: NotificationService
  ) {
    this.form = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required]],
      specialization: ['', Validators.required],
      experienceYears: [1, [Validators.required, Validators.min(0)]],
      consultationFee: [500, [Validators.required, Validators.min(0)]],
      hospitalName: ['', Validators.required],
      city: ['', Validators.required],
      registrationNumber: ['', Validators.required],
      about: ['']
    });
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.notifications.error('Please fix validation errors before submitting.');
      return;
    }
    this.submitting = true;
    this.doctorsService.registerDoctor(this.form.value).subscribe({
      next: () => {
        this.submitting = false;
        this.notifications.success('Doctor registered successfully.');
        this.form.reset();
      },
      error: () => {
        this.submitting = false;
        this.notifications.error('Failed to register doctor.');
      }
    });
  }

  get f() {
    return this.form.controls;
  }
}
