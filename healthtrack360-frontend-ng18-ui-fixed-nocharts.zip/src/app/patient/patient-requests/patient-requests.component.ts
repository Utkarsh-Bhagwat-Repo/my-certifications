import { Component, OnInit } from '@angular/core';
import { PatientRequest } from '../../core/models/request.models';
import { RequestsService } from '../../services/requests.service';

@Component({
  selector: 'app-patient-requests',
  templateUrl: './patient-requests.component.html',
  styleUrls: ['./patient-requests.component.scss']
})
export class PatientRequestsComponent implements OnInit {
  requests: PatientRequest[] = [];
  loading = false;

  constructor(private requestsService: RequestsService) {}

  ngOnInit(): void {
    this.loading = true;
    this.requestsService.getMyRequests().subscribe({
      next: res => {
        this.requests = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }
}
