package com.healthtrack360.domain.enums;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_DOCTOR,
    ROLE_PATIENT
}
