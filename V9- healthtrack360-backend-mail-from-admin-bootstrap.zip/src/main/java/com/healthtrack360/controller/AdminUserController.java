package com.healthtrack360.controller;

import com.healthtrack360.domain.User;
import com.healthtrack360.dto.AdminCreateRequest;
import com.healthtrack360.dto.AdminUpdateRequest;
import com.healthtrack360.service.AdminUserService;
import com.healthtrack360.service.CurrentUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/admins")
public class AdminUserController {

    private final AdminUserService adminUserService;
    private final CurrentUserService currentUserService;

    public AdminUserController(AdminUserService adminUserService,
                               CurrentUserService currentUserService) {
        this.adminUserService = adminUserService;
        this.currentUserService = currentUserService;
    }

    /**
     * Create another admin.
     * Any authenticated admin can create a new admin user.
     */
    @PostMapping
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<User> createAdmin(@RequestBody AdminCreateRequest request) {
        User created = adminUserService.createAdmin(request);
        return ResponseEntity.ok(created);
    }

    /**
     * Update current logged-in admin's own account only.
     */
    @PutMapping("/me")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<User> updateSelf(@AuthenticationPrincipal UserDetails userDetails,
                                           @RequestBody AdminUpdateRequest request) {
        Long currentUserId = currentUserService.getUserId(userDetails);
        User updated = adminUserService.updateSelf(currentUserId, request);
        return ResponseEntity.ok(updated);
    }

    /**
     * Delete current logged-in admin's own account only.
     */
    @DeleteMapping("/me")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> deleteSelf(@AuthenticationPrincipal UserDetails userDetails) {
        Long currentUserId = currentUserService.getUserId(userDetails);
        adminUserService.deleteSelf(currentUserId);
        return ResponseEntity.noContent().build();
    }
}
