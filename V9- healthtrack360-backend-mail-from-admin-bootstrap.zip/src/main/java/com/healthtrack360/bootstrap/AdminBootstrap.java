package com.healthtrack360.bootstrap;

import com.healthtrack360.domain.User;
import com.healthtrack360.domain.enums.RoleName;
import com.healthtrack360.repository.UserRepository;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class AdminBootstrap {

    private static final Logger log = LoggerFactory.getLogger(AdminBootstrap.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.admin.email}")
    private String adminEmail;

    @Value("${app.admin.password}")
    private String adminPassword;

    @Value("${app.admin.bootstrap-enabled:true}")
    private boolean bootstrapEnabled;

    public AdminBootstrap(UserRepository userRepository,
                          PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostConstruct
    public void initAdmin() {
        if (!bootstrapEnabled) {
            log.info("Admin bootstrap disabled by configuration");
            return;
        }
        if (adminEmail == null || adminEmail.isBlank() ||
                adminPassword == null || adminPassword.isBlank()) {
            log.warn("Admin bootstrap skipped: app.admin.email or app.admin.password not configured");
            return;
        }

        userRepository.findByEmail(adminEmail).ifPresentOrElse(existing -> {
            if (!existing.getRoles().contains(RoleName.ROLE_ADMIN)) {
                existing.getRoles().add(RoleName.ROLE_ADMIN);
                userRepository.save(existing);
                log.info("Existing user {} promoted to admin", adminEmail);
            } else {
                log.info("Admin user {} already exists", adminEmail);
            }
        }, () -> {
            User admin = new User();
            admin.setEmail(adminEmail);
            admin.setPassword(passwordEncoder.encode(adminPassword));
            admin.setEnabled(true);
            admin.getRoles().add(RoleName.ROLE_ADMIN);
            userRepository.save(admin);
            log.info("Admin user created at startup with email {}", adminEmail);
        });
    }
}
