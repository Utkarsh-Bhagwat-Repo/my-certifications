package com.healthtrack360.service;

import com.healthtrack360.domain.User;
import com.healthtrack360.domain.enums.RoleName;
import com.healthtrack360.dto.AdminCreateRequest;
import com.healthtrack360.dto.AdminUpdateRequest;
import com.healthtrack360.exception.BusinessValidationException;
import com.healthtrack360.exception.ConflictException;
import com.healthtrack360.exception.ResourceNotFoundException;
import com.healthtrack360.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminUserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminUserService(UserRepository userRepository,
                            PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public User createAdmin(AdminCreateRequest request) {
        if (request.getEmail() == null || request.getEmail().isBlank()) {
            throw new BusinessValidationException("Email is required");
        }
        if (request.getPassword() == null || request.getPassword().isBlank()) {
            throw new BusinessValidationException("Password is required");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new ConflictException("Email already registered");
        }

        User admin = new User();
        admin.setEmail(request.getEmail());
        admin.setPassword(passwordEncoder.encode(request.getPassword()));
        admin.setEnabled(request.getEnabled() == null ? true : request.getEnabled());
        admin.getRoles().add(RoleName.ROLE_ADMIN);

        return userRepository.save(admin);
    }

    @Transactional
    public User updateSelf(Long currentUserId, AdminUpdateRequest request) {
        User admin = userRepository.findById(currentUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found"));

        if (!admin.getRoles().contains(RoleName.ROLE_ADMIN)) {
            throw new BusinessValidationException("User is not an admin");
        }

        if (request.getEmail() != null && !request.getEmail().isBlank()
                && !request.getEmail().equals(admin.getEmail())) {
            if (userRepository.existsByEmail(request.getEmail())) {
                throw new ConflictException("Email already registered");
            }
            admin.setEmail(request.getEmail());
        }

        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            admin.setPassword(passwordEncoder.encode(request.getPassword()));
        }

        if (request.getEnabled() != null) {
            admin.setEnabled(request.getEnabled());
        }

        return userRepository.save(admin);
    }

    @Transactional
    public void deleteSelf(Long currentUserId) {
        User admin = userRepository.findById(currentUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found"));

        if (!admin.getRoles().contains(RoleName.ROLE_ADMIN)) {
            throw new BusinessValidationException("User is not an admin");
        }

        userRepository.delete(admin);
    }
}
