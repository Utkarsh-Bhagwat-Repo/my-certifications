package com.healthtrack360.domain.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
