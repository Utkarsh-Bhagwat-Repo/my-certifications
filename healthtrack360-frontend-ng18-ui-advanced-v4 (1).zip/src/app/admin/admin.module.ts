import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminDoctorsComponent } from './admin-doctors/admin-doctors.component';
import { AdminPatientsComponent } from './admin-patients/admin-patients.component';

@NgModule({
  declarations: [
    AdminDashboardComponent,
    AdminDoctorsComponent,
    AdminPatientsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    AdminRoutingModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AdminModule {}
