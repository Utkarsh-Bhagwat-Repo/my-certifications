import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminDoctorsComponent } from './admin-doctors/admin-doctors.component';
import { AdminPatientsComponent } from './admin-patients/admin-patients.component';

const routes: Routes = [
  { path: '', component: AdminDashboardComponent },
  { path: 'doctors', component: AdminDoctorsComponent },
  { path: 'patients', component: AdminPatientsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}
