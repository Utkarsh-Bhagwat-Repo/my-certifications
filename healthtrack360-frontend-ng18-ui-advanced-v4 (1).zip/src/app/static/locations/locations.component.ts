import { Component } from '@angular/core';

interface HospitalLocation {
  name: string;
  city: string;
  address: string;
  pin: string;
  phone: string;
}

@Component({
  selector: 'app-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.scss']
})
export class LocationsComponent {
  locations: HospitalLocation[] = [
    {
      name: 'HealthTrack 360 - Central Hospital',
      city: 'Pune',
      address: 'Plot 21, Ring Road, Shivaji Nagar',
      pin: '411005',
      phone: '+91-90210-00001'
    },
    {
      name: 'HealthTrack 360 - East Care',
      city: 'Pune',
      address: 'Near IT Park, Kharadi',
      pin: '411014',
      phone: '+91-90210-00002'
    },
    {
      name: 'HealthTrack 360 - City Clinic',
      city: 'Mumbai',
      address: 'Link Road, Andheri West',
      pin: '400053',
      phone: '+91-90210-00003'
    }
  ];
}
