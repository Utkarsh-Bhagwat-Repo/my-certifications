import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function dateInPastValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    if (!value) return null;
    const inputDate = new Date(value);
    const today = new Date();
    if (isNaN(inputDate.getTime())) return { dateInvalid: true };
    if (inputDate >= today) return { dateNotPast: true };
    return null;
  };
}
