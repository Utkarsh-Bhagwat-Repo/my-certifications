
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AppointmentFilter } from '../../models/filters.model';

@Component({
  selector: 'ht-appointment-filters',
  templateUrl: './appointment-filters.component.html',
  styleUrls: ['./appointment-filters.component.scss']
})
export class AppointmentFiltersComponent implements OnInit {

  @Input() initialFilter: AppointmentFilter | null = null;
  @Output() filterChange = new EventEmitter<AppointmentFilter>();

  form!: FormGroup;
  specializations: string[] = ['Cardiologist', 'Dermatologist', 'Neurologist', 'Orthopedic', 'Pediatrician'];
  cities: string[] = ['Mumbai', 'Pune', 'Delhi', 'Bangalore'];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      specialization: [this.initialFilter?.specialization ?? null],
      city: [this.initialFilter?.city ?? null],
      date: [this.initialFilter?.date ?? null],
      dayOfWeek: [this.initialFilter?.dayOfWeek ?? null],
      sortBy: [this.initialFilter?.sortBy ?? null]
    });

    this.form.valueChanges.subscribe(val => {
      this.filterChange.emit(val);
    });
  }

  clear(): void {
    this.form.reset();
    this.filterChange.emit({});
  }
}
