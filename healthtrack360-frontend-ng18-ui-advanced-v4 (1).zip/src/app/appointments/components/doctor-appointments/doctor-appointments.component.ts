import { Component, OnInit } from '@angular/core';
import { AppointmentsService } from '../../services/appointments.service';
import { Appointment } from '../../models/appointment.model';
import { NotificationService } from '../../../core/notification/notification.service';

@Component({
  selector: 'ht-doctor-appointments',
  templateUrl: './doctor-appointments.component.html',
  styleUrls: ['./doctor-appointments.component.scss']
})
export class DoctorAppointmentsComponent implements OnInit {

  appointments: Appointment[] = [];
  loading = false;

  fromDate!: string;
  toDate!: string;
  statusFilter: string = '';

  constructor(
    private appointmentsService: AppointmentsService,
    private notifications: NotificationService
  ) {}

  ngOnInit(): void {
    const today = new Date();
    const start = new Date();
    start.setDate(today.getDate() - 7);
    this.fromDate = start.toISOString().substring(0, 10);
    this.toDate = today.toISOString().substring(0, 10);
    this.load();
  }

  load(): void {
    this.loading = true;
    this.appointmentsService.getDoctorAppointments(
      this.fromDate,
      this.toDate,
      this.statusFilter || undefined
    ).subscribe({
      next: res => {
        this.appointments = res;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.notifications.error('Unable to load appointments.');
      }
    });
  }

  onStatusFilterChange(value: string): void {
    this.statusFilter = value;
    this.load();
  }
}
