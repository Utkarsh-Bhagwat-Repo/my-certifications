
import { Component, OnInit } from '@angular/core';
import { Doctor } from '../../models/doctor.model';
import { AppointmentFilter } from '../../models/filters.model';
import { DoctorsService } from '../../services/doctors.service';

@Component({
  selector: 'ht-appointment-dashboard',
  templateUrl: './appointment-dashboard.component.html',
  styleUrls: ['./appointment-dashboard.component.scss']
})
export class AppointmentDashboardComponent implements OnInit {

  doctors: Doctor[] = [];
  loading = false;
  filter: AppointmentFilter = {};
  selectedDoctor?: Doctor;

  constructor(private doctorsService: DoctorsService) {}

  ngOnInit(): void {
    this.loadDoctors();
  }

  onFilterChange(filter: AppointmentFilter): void {
    this.filter = filter;
    this.loadDoctors();
  }

  onDoctorSelected(doc: Doctor): void {
    this.selectedDoctor = doc;
  }

  private loadDoctors(): void {
    this.loading = true;
    this.doctorsService.getDoctors(this.filter).subscribe({
      next: (data) => {
        this.doctors = data;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }
}
