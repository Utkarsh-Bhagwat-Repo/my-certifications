import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Appointment } from '../models/appointment.model';

@Injectable({ providedIn: 'root' })
export class AppointmentsService {
  private readonly baseUrl = `${environment.apiBaseUrl}/v1/appointments`;

  constructor(private http: HttpClient) {}

  bookAppointment(payload: any): Observable<Appointment> {
    return this.http.post<Appointment>(this.baseUrl, payload);
  }

  getMyAppointments(): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(`${this.baseUrl}/patient`);
  }

  getDoctorAppointments(fromDate?: string, toDate?: string, status?: string): Observable<Appointment[]> {
    let params = new HttpParams();
    if (fromDate) params = params.set('from', fromDate);
    if (toDate) params = params.set('to', toDate);
    if (status) params = params.set('status', status);
    return this.http.get<Appointment[]>(`${this.baseUrl}/doctor`, { params });
  }

  cancelAppointment(id: number): Observable<void> {
    return this.http.patch<void>(`${this.baseUrl}/${id}/cancel`, {});
  }

  updateAppointment(id: number, payload: { concern?: string }): Observable<Appointment> {
    return this.http.patch<Appointment>(`${this.baseUrl}/${id}`, payload);
  }
}
