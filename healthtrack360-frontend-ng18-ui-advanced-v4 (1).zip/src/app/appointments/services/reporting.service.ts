
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface DailyAppointmentStats {
  date: string;
  totalAppointments: number;
  completed: number;
  cancelled: number;
}

export interface SpecializationStats {
  specialization: string;
  totalAppointments: number;
}

export interface DoctorUtilizationStats {
  doctorId: number;
  doctorName: string;
  utilizationPercent: number;
}

@Injectable({ providedIn: 'root' })
export class ReportingService {
  private readonly baseUrl = `${environment.apiBaseUrl}/v1/reports`;

  constructor(private http: HttpClient) {}

  getDailyStats(fromDate: string, toDate: string): Observable<DailyAppointmentStats[]> {
    const params = new HttpParams().set('from', fromDate).set('to', toDate);
    return this.http.get<DailyAppointmentStats[]>(`${this.baseUrl}/daily`, { params });
  }

  getSpecializationStats(fromDate: string, toDate: string): Observable<SpecializationStats[]> {
    const params = new HttpParams().set('from', fromDate).set('to', toDate);
    return this.http.get<SpecializationStats[]>(`${this.baseUrl}/specialization`, { params });
  }

  getDoctorUtilization(fromDate: string, toDate: string): Observable<DoctorUtilizationStats[]> {
    const params = new HttpParams().set('from', fromDate).set('to', toDate);
    return this.http.get<DoctorUtilizationStats[]>(`${this.baseUrl}/doctor-utilization`, { params });
  }
}
