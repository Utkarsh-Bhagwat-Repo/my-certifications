
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppointmentDashboardComponent } from './components/appointment-dashboard/appointment-dashboard.component';
import { PatientMyAppointmentsComponent } from './components/patient-my-appointments/patient-my-appointments.component';
import { DoctorAppointmentsComponent } from './components/doctor-appointments/doctor-appointments.component';
import { AdminDoctorRegistrationComponent } from './components/admin-doctor-registration/admin-doctor-registration.component';
import { AdminAvailabilityConfigComponent } from './components/admin-availability-config/admin-availability-config.component';
import { ReportsDashboardComponent } from './components/reports-dashboard/reports-dashboard.component';

const routes: Routes = [
  { path: '', component: AppointmentDashboardComponent },
  { path: 'my', component: PatientMyAppointmentsComponent },
  { path: 'doctor', component: DoctorAppointmentsComponent },
  { path: 'admin/doctors/new', component: AdminDoctorRegistrationComponent },
  { path: 'admin/availability', component: AdminAvailabilityConfigComponent },
  { path: 'reports', component: ReportsDashboardComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppointmentsRoutingModule { }
