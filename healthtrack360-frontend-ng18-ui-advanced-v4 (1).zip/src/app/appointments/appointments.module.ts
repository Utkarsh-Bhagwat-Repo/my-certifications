import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgChartsModule } from 'ng2-charts';

import { AppointmentsRoutingModule } from './appointments-routing.module';

import { AppointmentDashboardComponent } from './components/appointment-dashboard/appointment-dashboard.component';
import { AppointmentFiltersComponent } from './components/appointment-filters/appointment-filters.component';
import { DoctorListComponent } from './components/doctor-list/doctor-list.component';
import { DoctorAvailabilityGridComponent } from './components/doctor-availability-grid/doctor-availability-grid.component';
import { PatientMyAppointmentsComponent } from './components/patient-my-appointments/patient-my-appointments.component';
import { DoctorAppointmentsComponent } from './components/doctor-appointments/doctor-appointments.component';
import { AdminDoctorRegistrationComponent } from './components/admin-doctor-registration/admin-doctor-registration.component';
import { AdminAvailabilityConfigComponent } from './components/admin-availability-config/admin-availability-config.component';
import { ReportsDashboardComponent } from './components/reports-dashboard/reports-dashboard.component';

@NgModule({
  declarations: [
    AppointmentDashboardComponent,
    AppointmentFiltersComponent,
    DoctorListComponent,
    DoctorAvailabilityGridComponent,
    PatientMyAppointmentsComponent,
    DoctorAppointmentsComponent,
    AdminDoctorRegistrationComponent,
    AdminAvailabilityConfigComponent,
    ReportsDashboardComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    AppointmentsRoutingModule,
    NgChartsModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppointmentsModule { }
