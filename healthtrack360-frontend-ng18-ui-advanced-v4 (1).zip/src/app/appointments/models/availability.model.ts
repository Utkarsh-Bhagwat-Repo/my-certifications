
export interface AvailabilitySlotConfig {
  doctorId: number;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  slotDurationMinutes: number;
  isRecurring: boolean;
}
