import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Appointment } from '../core/models/appointment.models';

@Injectable({ providedIn: 'root' })
export class AppointmentsService {
  private baseUrl = `${environment.apiBaseUrl}/appointments`;

  constructor(private http: HttpClient) {}

  getMyAppointments(): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(`${this.baseUrl}/me`);
  }

  getDoctorTodayAppointments(): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(`${this.baseUrl}/doctor/today`);
  }

  bookAppointment(payload: { doctorId: number; appointmentTime: string }): Observable<Appointment> {
    return this.http.post<Appointment>(this.baseUrl, payload);
  }

  updateStatus(id: number, status: string): Observable<Appointment> {
    const params = new HttpParams().set('status', status);
    return this.http.put<Appointment>(`${this.baseUrl}/${id}/status`, null, { params });
  }

  searchById(id: number): Observable<Appointment> {
    return this.http.get<Appointment>(`${this.baseUrl}/${id}`);
  }
}
