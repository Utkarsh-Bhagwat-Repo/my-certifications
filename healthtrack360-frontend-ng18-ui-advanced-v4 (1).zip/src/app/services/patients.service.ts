import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { PatientResponse } from '../core/models/patient.models';

@Injectable({ providedIn: 'root' })
export class PatientsService {
  private baseUrl = `${environment.apiBaseUrl}/patients`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<PatientResponse[]> {
    return this.http.get<PatientResponse[]>(this.baseUrl);
  }

  getById(id: number): Observable<PatientResponse> {
    return this.http.get<PatientResponse>(`${this.baseUrl}/${id}`);
  }

  getMe(): Observable<PatientResponse> {
    return this.http.get<PatientResponse>(`${this.baseUrl}/me`);
  }
}
