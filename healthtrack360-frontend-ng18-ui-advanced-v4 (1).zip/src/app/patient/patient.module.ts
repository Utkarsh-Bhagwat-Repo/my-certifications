import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { PatientRoutingModule } from './patient-routing.module';
import { PatientDashboardComponent } from './patient-dashboard/patient-dashboard.component';
import { PatientAppointmentsComponent } from './patient-appointments/patient-appointments.component';
import { PatientRecordsComponent } from './patient-records/patient-records.component';
import { PatientRequestsComponent } from './patient-requests/patient-requests.component';

@NgModule({
  declarations: [
    PatientDashboardComponent,
    PatientAppointmentsComponent,
    PatientRecordsComponent,
    PatientRequestsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    PatientRoutingModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PatientModule {}
