import { Component, OnInit } from '@angular/core';
import { Appointment } from '../../core/models/appointment.models';
import { AppointmentsService } from '../../services/appointments.service';
import { NotificationService } from '../../core/notification/notification.service';

@Component({
  selector: 'app-doctor-appointments',
  templateUrl: './doctor-appointments.component.html',
  styleUrls: ['./doctor-appointments.component.scss']
})
export class DoctorAppointmentsComponent implements OnInit {
  appointments: Appointment[] = [];
  loading = false;

  constructor(
    private appointmentsService: AppointmentsService,
    private notifications: NotificationService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.appointmentsService.getDoctorTodayAppointments().subscribe({
      next: res => {
        this.appointments = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  approve(id: number): void {
    this.appointmentsService.updateStatus(id, 'APPROVED').subscribe({
      next: () => {
        this.notifications.success('Appointment approved.');
        this.appointments = this.appointments.map(a => a.id === id ? { ...a, status: 'APPROVED' } : a);
      }
    });
  }

  reject(id: number): void {
    this.appointmentsService.updateStatus(id, 'REJECTED').subscribe({
      next: () => {
        this.notifications.success('Appointment rejected.');
        this.appointments = this.appointments.map(a => a.id === id ? { ...a, status: 'REJECTED' } : a);
      }
    });
  }
}
