import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { PatientRequest } from '../core/models/request.models';

@Injectable({ providedIn: 'root' })
export class RequestsService {
  private baseUrl = `${environment.apiBaseUrl}/requests`;

  constructor(private http: HttpClient) {}

  getMyRequests(): Observable<PatientRequest[]> {
    return this.http.get<PatientRequest[]>(`${this.baseUrl}/me`);
  }
}
