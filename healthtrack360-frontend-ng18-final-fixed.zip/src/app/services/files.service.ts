import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class FilesService {
  private baseUrl = `${environment.apiBaseUrl}/files`;

  constructor(private http: HttpClient) {}

  upload(file: File): Observable<number> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<number>(this.baseUrl, formData);
  }

  download(id: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/${id}`, { responseType: 'blob' });
  }
}
