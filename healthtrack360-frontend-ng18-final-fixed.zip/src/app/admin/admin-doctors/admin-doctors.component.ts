import { Component, OnInit } from '@angular/core';
import { DoctorResponse } from '../../core/models/doctor.models';
import { DoctorsService } from '../../services/doctors.service';

@Component({
  selector: 'app-admin-doctors',
  templateUrl: './admin-doctors.component.html',
  styleUrls: ['./admin-doctors.component.scss']
})
export class AdminDoctorsComponent implements OnInit {
  displayedColumns = ['id', 'fullName', 'specialization', 'email', 'enabled'];
  data: DoctorResponse[] = [];
  loading = false;

  constructor(private doctorsService: DoctorsService) {}

  ngOnInit(): void {
    this.loading = true;
    this.doctorsService.getAll().subscribe({
      next: res => {
        this.data = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }
}
