import { Component, OnInit } from '@angular/core';
import { PatientResponse } from '../../core/models/patient.models';
import { PatientsService } from '../../services/patients.service';

@Component({
  selector: 'app-admin-patients',
  templateUrl: './admin-patients.component.html',
  styleUrls: ['./admin-patients.component.scss']
})
export class AdminPatientsComponent implements OnInit {
  displayedColumns = ['id', 'patientCode', 'givenName', 'familyName', 'email', 'enabled'];
  data: PatientResponse[] = [];
  loading = false;

  constructor(private patientsService: PatientsService) {}

  ngOnInit(): void {
    this.loading = true;
    this.patientsService.getAll().subscribe({
      next: res => {
        this.data = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }
}
