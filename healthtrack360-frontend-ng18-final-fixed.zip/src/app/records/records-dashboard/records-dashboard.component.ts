import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MedicalRecord } from '../../core/models/record.models';
import { RecordsService } from '../../services/records.service';
import { FilesService } from '../../services/files.service';
import { NotificationService } from '../../core/notification/notification.service';

@Component({
  selector: 'app-records-dashboard',
  templateUrl: './records-dashboard.component.html',
  styleUrls: ['./records-dashboard.component.scss']
})
export class RecordsDashboardComponent implements OnInit {
  displayedColumns = ['id', 'diagnosis', 'notes', 'createdAt'];
  data: MedicalRecord[] = [];
  loading = false;

  addForm = this.fb.group({
    patientId: ['', [Validators.required]],
    diagnosis: ['', [Validators.required]],
    notes: ['', [Validators.required]]
  });

  downloadFileId?: number;

  constructor(
    private fb: FormBuilder,
    private recordsService: RecordsService,
    private filesService: FilesService,
    private notifications: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadMyRecords();
  }

  loadMyRecords(): void {
    this.loading = true;
    this.recordsService.getMyRecords().subscribe({
      next: res => {
        this.data = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  addRecord(): void {
    if (this.addForm.invalid) {
      this.notifications.error('Patient, diagnosis and notes are required.');
      return;
    }
    this.loading = true;
    this.recordsService.addRecord(this.addForm.value as any).subscribe({
      next: () => {
        this.loading = false;
        this.notifications.success('Medical record added.');
        this.loadMyRecords();
      },
      error: () => this.loading = false
    });
  }

  download(): void {
    if (!this.downloadFileId) {
      this.notifications.error('Enter file ID to download.');
      return;
    }
    this.filesService.download(this.downloadFileId).subscribe({
      next: blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `medical-file-${this.downloadFileId}.bin`;
        a.click();
        window.URL.revokeObjectURL(url);
        this.notifications.success('File download started.');
      }
    });
  }
}
