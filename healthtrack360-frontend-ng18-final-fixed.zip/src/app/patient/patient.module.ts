import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';

import { PatientRoutingModule } from './patient-routing.module';
import { PatientDashboardComponent } from './patient-dashboard/patient-dashboard.component';
import { PatientAppointmentsComponent } from './patient-appointments/patient-appointments.component';
import { PatientRecordsComponent } from './patient-records/patient-records.component';
import { PatientRequestsComponent } from './patient-requests/patient-requests.component';

@NgModule({
  declarations: [
    PatientDashboardComponent,
    PatientAppointmentsComponent,
    PatientRecordsComponent,
    PatientRequestsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    PatientRoutingModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule
  ]
})
export class PatientModule {}
