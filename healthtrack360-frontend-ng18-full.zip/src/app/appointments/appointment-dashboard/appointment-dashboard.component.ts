import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Appointment } from '../../core/models/appointment.models';
import { AppointmentsService } from '../../services/appointments.service';
import { NotificationService } from '../../core/notification/notification.service';

@Component({
  selector: 'app-appointment-dashboard',
  templateUrl: './appointment-dashboard.component.html',
  styleUrls: ['./appointment-dashboard.component.scss']
})
export class AppointmentDashboardComponent {
  form: FormGroup;
  appointments: Appointment[] = [];
  loading = false;
  searchId?: number;
  searchResult?: Appointment;

  constructor(
    private fb: FormBuilder,
    private appointmentsService: AppointmentsService,
    private notifications: NotificationService
  ) {
    this.form = this.fb.group({
      doctorId: ['', [Validators.required]],
      appointmentTime: ['', [Validators.required]]
    });
  }

  book(): void {
    if (this.form.invalid) {
      this.notifications.error('Doctor and time are required.');
      return;
    }
    this.loading = true;
    this.appointmentsService.bookAppointment(this.form.value as any).subscribe({
      next: () => {
        this.loading = false;
        this.notifications.success('Appointment booked.');
        this.loadMyAppointments();
      },
      error: () => this.loading = false
    });
  }

  loadMyAppointments(): void {
    this.loading = true;
    this.appointmentsService.getMyAppointments().subscribe({
      next: res => {
        this.appointments = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  searchById(): void {
    if (!this.searchId) {
      this.notifications.error('Enter appointment ID to search.');
      return;
    }
    this.appointmentsService.searchById(this.searchId).subscribe({
      next: res => {
        this.searchResult = res;
      }
    });
  }
}
