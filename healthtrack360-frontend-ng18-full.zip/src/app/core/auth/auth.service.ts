import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of, switchMap, tap, catchError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LoginRequest, TokenResponse } from '../models/auth.models';

export type UserRole = 'ROLE_ADMIN' | 'ROLE_DOCTOR' | 'ROLE_PATIENT' | null;

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly accessTokenKey = 'ht360_access';
  private readonly refreshTokenKey = 'ht360_refresh';
  private readonly roleKey = 'ht360_role';

  private role$ = new BehaviorSubject<UserRole>(this.getStoredRole());

  constructor(private http: HttpClient) {}

  login(credentials: LoginRequest): Observable<void> {
    return this.http.post<TokenResponse>(`${environment.apiBaseUrl}/auth/login`, credentials)
      .pipe(
        tap(tokens => this.storeTokens(tokens)),
        switchMap(() => this.resolveRole())
      );
  }

  registerPatient(payload: any): Observable<any> {
    return this.http.post(`${environment.apiBaseUrl}/patients/register`, payload);
  }

  refreshTokens(): Observable<TokenResponse | null> {
    const refreshToken = this.getRefreshToken();
    if (!refreshToken) {
      return of(null);
    }
    return this.http.post<TokenResponse>(`${environment.apiBaseUrl}/auth/refresh`, { refreshToken })
      .pipe(
        tap(tokens => this.storeTokens(tokens)),
        catchError(() => of(null))
      );
  }

  logout(): void {
    localStorage.removeItem(this.accessTokenKey);
    localStorage.removeItem(this.refreshTokenKey);
    localStorage.removeItem(this.roleKey);
    this.role$.next(null);
  }

  getAccessToken(): string | null {
    return localStorage.getItem(this.accessTokenKey);
  }

  getRefreshToken(): string | null {
    return localStorage.getItem(this.refreshTokenKey);
  }

  isLoggedIn(): boolean {
    return !!this.getAccessToken();
  }

  hasRole(role: UserRole | string): boolean {
    return this.role$.value === role;
  }

  getRole(): UserRole {
    return this.role$.value;
  }

  getRoleChanges(): Observable<UserRole> {
    return this.role$.asObservable();
  }

  private getStoredRole(): UserRole {
    const r = localStorage.getItem(this.roleKey) as UserRole | null;
    return r ?? null;
  }

  private storeTokens(tokens: TokenResponse): void {
    localStorage.setItem(this.accessTokenKey, tokens.accessToken);
    localStorage.setItem(this.refreshTokenKey, tokens.refreshToken);
  }

  private storeRole(role: UserRole): void {
    if (role) {
      localStorage.setItem(this.roleKey, role);
    } else {
      localStorage.removeItem(this.roleKey);
    }
    this.role$.next(role);
  }

  resolveRole(): Observable<void> {
    if (!this.isLoggedIn()) {
      this.storeRole(null);
      return of(void 0);
    }

    return this.http.get(`${environment.apiBaseUrl}/patients/me`).pipe(
      tap(() => this.storeRole('ROLE_PATIENT')),
      catchError(() => this.http.get(`${environment.apiBaseUrl}/admin/admins/me`).pipe(
        tap(() => this.storeRole('ROLE_ADMIN')),
        catchError(() => this.http.get(`${environment.apiBaseUrl}/appointments/doctor/today`).pipe(
          tap(() => this.storeRole('ROLE_DOCTOR')),
          catchError(() => {
            this.storeRole(null);
            return of(null);
          })
        ))
      )),
      switchMap(() => of(void 0))
    );
  }
}
