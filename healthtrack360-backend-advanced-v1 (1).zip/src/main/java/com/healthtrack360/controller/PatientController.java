package com.healthtrack360.controller;

import com.healthtrack360.domain.Patient;
import com.healthtrack360.dto.PatientResponse;
import com.healthtrack360.dto.PatientRegistrationRequest;
import com.healthtrack360.dto.PatientUpdateRequest;
import com.healthtrack360.service.CurrentUserService;
import com.healthtrack360.service.PatientService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    private final PatientService patientService;
    private final CurrentUserService currentUserService;

    public PatientController(PatientService patientService,
                             CurrentUserService currentUserService) {
        this.patientService = patientService;
        this.currentUserService = currentUserService;
    }

    @PostMapping("/register")
    public ResponseEntity<PatientResponse> register(@RequestBody PatientRegistrationRequest request) {
        Patient created = patientService.register(request);
        return ResponseEntity.ok(PatientResponse.from(created));
    }

    @PutMapping("/me")
    @PreAuthorize("hasRole('ROLE_PATIENT')")
    public ResponseEntity<PatientResponse> update(
            @AuthenticationPrincipal UserDetails user,
            @RequestBody PatientUpdateRequest request) {
        Long userId = currentUserService.getUserId(user);
        Patient updated = patientService.updateDemographics(userId, request);
        return ResponseEntity.ok(PatientResponse.from(updated));
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('ROLE_PATIENT')")
    public ResponseEntity<PatientResponse> me(@AuthenticationPrincipal UserDetails user) {
        Long userId = currentUserService.getUserId(user);
        Patient patient = patientService.getCurrentPatient(userId);
        return ResponseEntity.ok(PatientResponse.from(patient));
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<List<PatientResponse>> all() {
        return ResponseEntity.ok(patientService.findAll().stream()
                .map(PatientResponse::from)
                .toList());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<PatientResponse> byId(@PathVariable Long id) {
        return ResponseEntity.ok(PatientResponse.from(patientService.findById(id)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        patientService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
