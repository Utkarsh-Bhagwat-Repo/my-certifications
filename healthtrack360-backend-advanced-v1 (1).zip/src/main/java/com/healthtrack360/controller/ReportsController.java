package com.healthtrack360.controller;

import com.healthtrack360.domain.Appointment;
import com.healthtrack360.domain.Doctor;
import com.healthtrack360.domain.enums.AppointmentStatus;
import com.healthtrack360.dto.DailyAppointmentStatsDto;
import com.healthtrack360.dto.DoctorUtilizationDto;
import com.healthtrack360.dto.SpecializationStatsDto;
import com.healthtrack360.repository.AppointmentRepository;
import com.healthtrack360.repository.DoctorRepository;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/reports")
public class ReportsController {

    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;

    public ReportsController(AppointmentRepository appointmentRepository,
                             DoctorRepository doctorRepository) {
        this.appointmentRepository = appointmentRepository;
        this.doctorRepository = doctorRepository;
    }

    @GetMapping("/daily")
    public ResponseEntity<List<DailyAppointmentStatsDto>> daily(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        LocalDateTime start = from.atStartOfDay();
        LocalDateTime end = to.plusDays(1).atStartOfDay();
        List<Appointment> appts = appointmentRepository.findAll().stream()
                .filter(a -> !a.getAppointmentTime().isBefore(start) && a.getAppointmentTime().isBefore(end))
                .collect(Collectors.toList());

        Map<LocalDate, List<Appointment>> grouped = appts.stream()
                .collect(Collectors.groupingBy(a -> a.getAppointmentTime().toLocalDate()));

        List<DailyAppointmentStatsDto> result = grouped.entrySet().stream()
                .map(e -> {
                    DailyAppointmentStatsDto dto = new DailyAppointmentStatsDto();
                    dto.setDate(e.getKey().toString());
                    dto.setTotalAppointments(e.getValue().size());
                    dto.setCompleted(e.getValue().stream().filter(a -> a.getStatus() == AppointmentStatus.COMPLETED).count());
                    dto.setCancelled(e.getValue().stream().filter(a -> a.getStatus() == AppointmentStatus.CANCELLED).count());
                    return dto;
                })
                .sorted(Comparator.comparing(DailyAppointmentStatsDto::getDate))
                .collect(Collectors.toList());

        return ResponseEntity.ok(result);
    }

    @GetMapping("/specialization")
    public ResponseEntity<List<SpecializationStatsDto>> specialization(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        LocalDateTime start = from.atStartOfDay();
        LocalDateTime end = to.plusDays(1).atStartOfDay();
        List<Appointment> appts = appointmentRepository.findAll().stream()
                .filter(a -> !a.getAppointmentTime().isBefore(start) && a.getAppointmentTime().isBefore(end))
                .collect(Collectors.toList());

        Map<String, Long> counts = appts.stream()
                .collect(Collectors.groupingBy(
                        a -> a.getDoctor().getSpecialization(),
                        Collectors.counting()
                ));

        List<SpecializationStatsDto> result = counts.entrySet().stream()
                .map(e -> {
                    SpecializationStatsDto dto = new SpecializationStatsDto();
                    dto.setSpecialization(e.getKey());
                    dto.setTotalAppointments(e.getValue());
                    return dto;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(result);
    }

    @GetMapping("/doctor-utilization")
    public ResponseEntity<List<DoctorUtilizationDto>> doctorUtilization(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        LocalDateTime start = from.atStartOfDay();
        LocalDateTime end = to.plusDays(1).atStartOfDay();

        List<Doctor> doctors = doctorRepository.findAll();
        List<DoctorUtilizationDto> result = new ArrayList<>();

        for (Doctor d : doctors) {
            long booked = d.getAppointments().stream()
                    .filter(a -> !a.getAppointmentTime().isBefore(start) && a.getAppointmentTime().isBefore(end))
                    .count();

            long totalSlots = 0L;
            if (d.getAvailability() != null) {
                totalSlots = d.getAvailability().size() * 10L; // simple approximation
            }

            DoctorUtilizationDto dto = new DoctorUtilizationDto();
            dto.setDoctorName(d.getFullName());
            dto.setBookedSlots(booked);
            dto.setTotalSlots(totalSlots);
            dto.setUtilizationPercent(totalSlots == 0 ? 0.0 : (booked * 100.0) / totalSlots);
            result.add(dto);
        }

        return ResponseEntity.ok(result);
    }
}
