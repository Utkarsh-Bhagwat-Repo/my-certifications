package com.healthtrack360.controller;

import com.healthtrack360.domain.Appointment;
import com.healthtrack360.domain.enums.AppointmentStatus;
import com.healthtrack360.dto.AppointmentRequest;
import com.healthtrack360.dto.AppointmentUpdateRequest;
import com.healthtrack360.dto.AppointmentV1CreateRequest;
import com.healthtrack360.service.AppointmentService;
import com.healthtrack360.service.CurrentUserService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/appointments")
public class AppointmentV1Controller {

    private final AppointmentService appointmentService;
    private final CurrentUserService currentUserService;

    public AppointmentV1Controller(AppointmentService appointmentService,
                                   CurrentUserService currentUserService) {
        this.appointmentService = appointmentService;
        this.currentUserService = currentUserService;
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_PATIENT')")
    public ResponseEntity<Appointment> book(
            @AuthenticationPrincipal UserDetails user,
            @RequestBody AppointmentV1CreateRequest request) {

        Long userId = currentUserService.getUserId(user);

        LocalDateTime start = LocalDateTime.parse(request.getStartTime());
        AppointmentRequest legacy = new AppointmentRequest();
        legacy.setDoctorId(request.getDoctorId());
        legacy.setAppointmentTime(start);
        legacy.setConcern(request.getConcern());

        Appointment created = appointmentService.bookAppointment(userId, legacy);
        return ResponseEntity.ok(created);
    }

    @GetMapping("/patient/{patientId}")
    @PreAuthorize("hasRole('ROLE_PATIENT')")
    public ResponseEntity<List<Appointment>> patientAppointments(
            @AuthenticationPrincipal UserDetails user,
            @PathVariable Long patientId) {
        Long userId = currentUserService.getUserId(user);
        // For now, patientId path variable is ignored to keep things simple and secure.
        return ResponseEntity.ok(appointmentService.getPatientAppointments(userId));
    }

    @GetMapping("/doctor")
    @PreAuthorize("hasRole('ROLE_DOCTOR')")
    public ResponseEntity<List<Appointment>> doctorAppointments(
            @AuthenticationPrincipal UserDetails user,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(required = false) String status) {

        Long userId = currentUserService.getUserId(user);
        Optional<AppointmentStatus> statusOpt =
                status == null || status.isBlank() ? Optional.empty() : Optional.of(AppointmentStatus.valueOf(status));

        return ResponseEntity.ok(
                appointmentService.getDoctorAppointments(userId, from, to, statusOpt)
        );
    }

    @PatchMapping("/{id}/cancel")
    @PreAuthorize("hasRole('ROLE_PATIENT')")
    public ResponseEntity<Appointment> cancel(
            @AuthenticationPrincipal UserDetails user,
            @PathVariable Long id) {
        Long userId = currentUserService.getUserId(user);
        Appointment updated = appointmentService.cancelAppointment(id, userId);
        return ResponseEntity.ok(updated);
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasRole('ROLE_PATIENT')")
    public ResponseEntity<Appointment> updateConcern(
            @AuthenticationPrincipal UserDetails user,
            @PathVariable Long id,
            @RequestBody AppointmentUpdateRequest request) {
        Long userId = currentUserService.getUserId(user);
        Appointment updated = appointmentService.updateAppointmentNotes(id, userId, request.getConcern());
        return ResponseEntity.ok(updated);
    }
}
