package com.healthtrack360.controller;

import com.healthtrack360.domain.Doctor;
import com.healthtrack360.domain.DoctorAvailability;
import com.healthtrack360.dto.DoctorCreateRequest;
import com.healthtrack360.dto.DoctorDirectoryResponse;
import com.healthtrack360.dto.DoctorResponse;
import com.healthtrack360.service.DoctorService;
import com.healthtrack360.repository.DoctorAvailabilityRepository;
import com.healthtrack360.repository.DoctorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/doctors")
public class DoctorDirectoryController {

    private final DoctorRepository doctorRepository;
    private final DoctorAvailabilityRepository availabilityRepository;
    private final DoctorService doctorService;

    public DoctorDirectoryController(DoctorRepository doctorRepository,
                                     DoctorAvailabilityRepository availabilityRepository,
                                     DoctorService doctorService) {
        this.doctorRepository = doctorRepository;
        this.availabilityRepository = availabilityRepository;
        this.doctorService = doctorService;
    }

    @GetMapping
    public ResponseEntity<List<DoctorDirectoryResponse>> search(
            @RequestParam(required = false) String specialization,
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String dayOfWeek) {

        List<Doctor> doctors = doctorRepository.findByEnabledTrue();

        if (specialization != null && !specialization.isBlank()) {
            String specLower = specialization.toLowerCase();
            doctors = doctors.stream()
                    .filter(d -> d.getSpecialization() != null &&
                            d.getSpecialization().toLowerCase().contains(specLower))
                    .collect(Collectors.toList());
        }

        if (city != null && !city.isBlank()) {
            String cityLower = city.toLowerCase();
            doctors = doctors.stream()
                    .filter(d -> d.getCity() != null &&
                            d.getCity().toLowerCase().contains(cityLower))
                    .collect(Collectors.toList());
        }

        DayOfWeek filterDay = null;
        if (dayOfWeek != null && !dayOfWeek.isBlank()) {
            filterDay = DayOfWeek.valueOf(dayOfWeek.toUpperCase());
        }

        DayOfWeek finalFilterDay = filterDay;
        List<DoctorDirectoryResponse> result = doctors.stream()
                .map(d -> {
                    List<DoctorAvailability> rules;
                    if (finalFilterDay != null) {
                        rules = availabilityRepository.findByDoctorAndDayOfWeek(d, finalFilterDay);
                    } else {
                        rules = d.getAvailability();
                    }
                    return DoctorDirectoryResponse.from(d, rules);
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(result);
    }

    @PostMapping
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<DoctorResponse> create(@RequestBody DoctorCreateRequest request) {
        Doctor created = doctorService.createDoctor(request);
        return ResponseEntity.ok(DoctorResponse.from(created));
    }
}
