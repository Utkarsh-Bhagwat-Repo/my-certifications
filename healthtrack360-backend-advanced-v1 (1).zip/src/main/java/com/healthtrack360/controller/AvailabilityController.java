package com.healthtrack360.controller;

import com.healthtrack360.domain.Doctor;
import com.healthtrack360.domain.DoctorAvailability;
import com.healthtrack360.dto.AvailabilitySlotConfigRequest;
import com.healthtrack360.exception.ResourceNotFoundException;
import com.healthtrack360.repository.DoctorAvailabilityRepository;
import com.healthtrack360.repository.DoctorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/availability")
public class AvailabilityController {

    private final DoctorRepository doctorRepository;
    private final DoctorAvailabilityRepository availabilityRepository;

    public AvailabilityController(DoctorRepository doctorRepository,
                                  DoctorAvailabilityRepository availabilityRepository) {
        this.doctorRepository = doctorRepository;
        this.availabilityRepository = availabilityRepository;
    }

    @PostMapping("/recurring")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Void> saveRecurring(@RequestBody List<AvailabilitySlotConfigRequest> configs) {
        if (configs == null || configs.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        Long doctorId = configs.get(0).getDoctorId();
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

        // simple strategy: remove existing rules for this doctor and recreate from configs
        List<DoctorAvailability> existing = doctor.getAvailability();
        availabilityRepository.deleteAll(existing);

        for (AvailabilitySlotConfigRequest cfg : configs) {
            DoctorAvailability rule = new DoctorAvailability();
            rule.setDoctor(doctor);
            rule.setDayOfWeek(DayOfWeek.valueOf(cfg.getDayOfWeek()));
            rule.setStartTime(LocalTime.parse(cfg.getStartTime()));
            rule.setEndTime(LocalTime.parse(cfg.getEndTime()));
            rule.setSlotDurationMinutes(cfg.getSlotDurationMinutes());
            availabilityRepository.save(rule);
        }

        return ResponseEntity.ok().build();
    }
}
