package com.healthtrack360.dto;

import java.time.LocalDateTime;

public class AppointmentRequest {

    private Long doctorId;
    private LocalDateTime appointmentTime;
    private String concern; // optional patient concern/notes

    public AppointmentRequest() {
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public LocalDateTime getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(LocalDateTime appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getConcern() {
        return concern;
    }

    public void setConcern(String concern) {
        this.concern = concern;
    }
}
