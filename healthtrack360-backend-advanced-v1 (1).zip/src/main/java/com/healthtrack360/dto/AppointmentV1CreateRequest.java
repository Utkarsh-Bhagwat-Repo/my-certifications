package com.healthtrack360.dto;

public class AppointmentV1CreateRequest {

    private Long doctorId;
    private String startTime; // ISO-8601 date time string
    private String endTime;   // optional, currently unused
    private String concern;

    public AppointmentV1CreateRequest() {
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getConcern() {
        return concern;
    }

    public void setConcern(String concern) {
        this.concern = concern;
    }
}
