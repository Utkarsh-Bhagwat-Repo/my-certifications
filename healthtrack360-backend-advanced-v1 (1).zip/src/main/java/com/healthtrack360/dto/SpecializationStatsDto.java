package com.healthtrack360.dto;

public class SpecializationStatsDto {

    private String specialization;
    private long totalAppointments;

    public SpecializationStatsDto() {
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public long getTotalAppointments() {
        return totalAppointments;
    }

    public void setTotalAppointments(long totalAppointments) {
        this.totalAppointments = totalAppointments;
    }
}
