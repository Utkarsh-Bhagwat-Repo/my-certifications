package com.healthtrack360.dto;

import com.healthtrack360.domain.Doctor;
import com.healthtrack360.domain.DoctorAvailability;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class DoctorDirectoryResponse {

    private Long id;
    private String fullName;
    private String specialization;
    private Integer experienceYears;
    private Double rating;
    private String hospitalName;
    private String city;
    private Double consultationFee;
    private List<String> availableDays;

    public DoctorDirectoryResponse() {
    }

    public static DoctorDirectoryResponse from(Doctor doctor, List<DoctorAvailability> rules) {
        DoctorDirectoryResponse dto = new DoctorDirectoryResponse();
        dto.setId(doctor.getId());
        dto.setFullName(doctor.getFullName());
        dto.setSpecialization(doctor.getSpecialization());
        dto.setExperienceYears(doctor.getYearsOfExperience());
        dto.setHospitalName(doctor.getHospitalName());
        dto.setCity(doctor.getCity());
        dto.setConsultationFee(doctor.getConsultationFee());

        if (rules != null && !rules.isEmpty()) {
            Set<DayOfWeek> days = rules.stream()
                    .map(DoctorAvailability::getDayOfWeek)
                    .collect(Collectors.toSet());
            dto.setAvailableDays(days.stream().map(Enum::name).sorted().collect(Collectors.toList()));
        }

        return dto;
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Integer getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(Integer experienceYears) {
        this.experienceYears = experienceYears;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Double getConsultationFee() {
        return consultationFee;
    }

    public void setConsultationFee(Double consultationFee) {
        this.consultationFee = consultationFee;
    }

    public List<String> getAvailableDays() {
        return availableDays;
    }

    public void setAvailableDays(List<String> availableDays) {
        this.availableDays = availableDays;
    }
}
