package com.healthtrack360.dto;

public class AppointmentUpdateRequest {

    private String concern;

    public AppointmentUpdateRequest() {
    }

    public String getConcern() {
        return concern;
    }

    public void setConcern(String concern) {
        this.concern = concern;
    }
}
