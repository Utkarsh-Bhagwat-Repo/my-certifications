package models

// Patient represents a patient entity
type Patient struct {
    ID   int     `json:"id"`
    Name string  `json:"name"`
    Age  float64 `json:"age"`
}