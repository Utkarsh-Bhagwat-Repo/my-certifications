package routes

import (
    "net/http"

    "patientcrud/handlers"
)

func RegisterRoutes() http.Handler {
    mux := http.NewServeMux()

    mux.HandleFunc("/patients", handlers.GetAllPatients)
    mux.HandleFunc("/patient", handlers.GetPatientByID)
    mux.HandleFunc("/add", handlers.AddPatient)
    mux.HandleFunc("/update", handlers.UpdatePatient)
    mux.HandleFunc("/delete", handlers.DeletePatient)
    mux.HandleFunc("/deleteAll", handlers.DeleteAllPatients)
    mux.HandleFunc("/count", handlers.CountPatients)

    return mux
}