package handlers

import (
    "encoding/json"
    "net/http"
    "strconv"

    "patientcrud/models"
    "patientcrud/store"
)

func respondJSON(w http.ResponseWriter, status int, payload interface{}) {
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(status)
    json.NewEncoder(w).Encode(payload)
}

func GetAllPatients(w http.ResponseWriter, r *http.Request) {
    respondJSON(w, http.StatusOK, store.GetAll())
}

func GetPatientByID(w http.ResponseWriter, r *http.Request) {
    id, _ := strconv.Atoi(r.URL.Query().Get("id"))
    p, err := store.GetByID(id)
    if err != nil {
        respondJSON(w, http.StatusNotFound, err.Error())
        return
    }
    respondJSON(w, http.StatusOK, p)
}

func AddPatient(w http.ResponseWriter, r *http.Request) {
    var p models.Patient
    json.NewDecoder(r.Body).Decode(&p)
    respondJSON(w, http.StatusCreated, store.AddPatient(p))
}

func UpdatePatient(w http.ResponseWriter, r *http.Request) {
    id, _ := strconv.Atoi(r.URL.Query().Get("id"))
    var p models.Patient
    json.NewDecoder(r.Body).Decode(&p)
    err := store.UpdateByID(id, p)
    if err != nil {
        respondJSON(w, http.StatusNotFound, err.Error())
        return
    }
    respondJSON(w, http.StatusOK, "updated")
}

func DeletePatient(w http.ResponseWriter, r *http.Request) {
    id, _ := strconv.Atoi(r.URL.Query().Get("id"))
    err := store.DeleteByID(id)
    if err != nil {
        respondJSON(w, http.StatusNotFound, err.Error())
        return
    }
    respondJSON(w, http.StatusOK, "deleted")
}

func DeleteAllPatients(w http.ResponseWriter, r *http.Request) {
    store.DeleteAll()
    respondJSON(w, http.StatusOK, "all deleted")
}

// Advanced feature example
func CountPatients(w http.ResponseWriter, r *http.Request) {
    respondJSON(w, http.StatusOK, store.Count())
}