package store

import (
    "errors"
    "sync"

    "patientcrud/models"
)

// In-memory data store using slice
var (
    patients []models.Patient
    mu       sync.Mutex
    nextID   = 1
)

// Preload data at app startup
func init() {
    AddPatient(models.Patient{Name: "Amit", Age: 30})
    AddPatient(models.Patient{Name: "Chinmay", Age: 28})
    AddPatient(models.Patient{Name: "Karan", Age: 26})
    AddPatient(models.Patient{Name: "Utkarsh", Age: 25})
}

func GetAll() []models.Patient {
    return patients
}

func GetByID(id int) (*models.Patient, error) {
    for _, p := range patients {
        if p.ID == id {
            return &p, nil
        }
    }
    return nil, errors.New("patient not found")
}

func AddPatient(p models.Patient) models.Patient {
    mu.Lock()
    defer mu.Unlock()

    p.ID = nextID
    nextID++
    patients = append(patients, p)
    return p
}

func UpdateByID(id int, updated models.Patient) error {
    for i, p := range patients {
        if p.ID == id {
            patients[i].Name = updated.Name
            patients[i].Age = updated.Age
            return nil
        }
    }
    return errors.New("patient not found")
}

func DeleteByID(id int) error {
    for i, p := range patients {
        if p.ID == id {
            patients = append(patients[:i], patients[i+1:]...)
            return nil
        }
    }
    return errors.New("patient not found")
}

func DeleteAll() {
    patients = []models.Patient{}
}

// Additional slice utility examples

// Filter patients above age
func FilterAboveAge(age float64) []models.Patient {
    result := []models.Patient{}
    for _, p := range patients {
        if p.Age > age {
            result = append(result, p)
        }
    }
    return result
}

// Count patients
func Count() int {
    return len(patients)
}