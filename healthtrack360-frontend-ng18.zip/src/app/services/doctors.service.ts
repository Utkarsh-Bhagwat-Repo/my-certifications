import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { DoctorResponse } from '../core/models/doctor.models';

@Injectable({ providedIn: 'root' })
export class DoctorsService {
  private baseUrl = `${environment.apiBaseUrl}/admin/doctors`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<DoctorResponse[]> {
    return this.http.get<DoctorResponse[]>(this.baseUrl);
  }
}
