import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminDoctorsComponent } from './admin-doctors/admin-doctors.component';
import { AdminPatientsComponent } from './admin-patients/admin-patients.component';

@NgModule({
  declarations: [
    AdminDashboardComponent,
    AdminDoctorsComponent,
    AdminPatientsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    AdminRoutingModule,
    MatCardModule,
    MatTableModule
  ]
})
export class AdminModule {}
