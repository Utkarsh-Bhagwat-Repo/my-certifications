import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { dateInPastValidator } from '../../shared/validators/date-in-past.validator';
import { AuthService } from '../../core/auth/auth.service';
import { NotificationService } from '../../core/notification/notification.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  isSubmitting = false;

  form = this.fb.group({
    givenName: ['', [Validators.required]],
    familyName: ['', [Validators.required]],
    gender: ['MALE', [Validators.required]],
    dateOfBirth: ['', [Validators.required, dateInPastValidator()]],
    addressLine1: [''],
    addressLine2: [''],
    country: ['', [Validators.required]],
    state: ['', [Validators.required]],
    city: ['', [Validators.required]],
    zip: ['', [Validators.required, Validators.pattern(/^\d{4,10}$/)]],
    phoneNumber: ['', [Validators.required, Validators.pattern(/^\+?[0-9]{10,15}$/)]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private notifications: NotificationService
  ) {}

  submit(): void {
    if (this.form.invalid) {
      this.notifications.error('Please fix validation errors before submitting.');
      return;
    }
    this.isSubmitting = true;

    this.auth.registerPatient(this.form.value).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.notifications.success('Registration successful. Please login.');
        this.router.navigate(['/auth/login']);
      },
      error: () => {
        this.isSubmitting = false;
      }
    });
  }
}
