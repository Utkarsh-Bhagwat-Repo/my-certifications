import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { AuthService, UserRole } from './auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(private auth: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const allowedRoles = route.data['roles'] as UserRole[] | undefined;

    if (!this.auth.isLoggedIn()) {
      this.router.navigate(['/auth/login'], { queryParams: { returnUrl: state.url } });
      return of(false);
    }

    return this.auth.resolveRole().pipe(
      switchMap(() => {
        if (!allowedRoles || allowedRoles.length === 0) {
          return of(true);
        }
        const currentRole = this.auth.getRole();
        if (currentRole && allowedRoles.includes(currentRole)) {
          return of(true);
        }
        this.router.navigate(['/']);
        return of(false);
      })
    );
  }
}
