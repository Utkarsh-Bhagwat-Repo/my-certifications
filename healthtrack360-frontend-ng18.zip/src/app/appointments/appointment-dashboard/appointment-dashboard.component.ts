import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AppointmentsService } from '../../services/appointments.service';
import { NotificationService } from '../../core/notification/notification.service';
import { Appointment } from '../../core/models/appointment.models';

@Component({
  selector: 'app-appointment-dashboard',
  templateUrl: './appointment-dashboard.component.html',
  styleUrls: ['./appointment-dashboard.component.scss']
})
export class AppointmentDashboardComponent {
  displayedColumns = ['id', 'appointmentTime', 'status', 'doctorName'];
  data: Appointment[] = [];
  loading = false;

  form = this.fb.group({
    doctorId: ['', [Validators.required]],
    appointmentTime: ['', [Validators.required]]
  });

  searchId?: number;
  searchResult?: Appointment;

  constructor(
    private fb: FormBuilder,
    private appointmentsService: AppointmentsService,
    private notifications: NotificationService
  ) {}

  book(): void {
    if (this.form.invalid) {
      this.notifications.error('Doctor and time are required.');
      return;
    }
    this.loading = true;
    this.appointmentsService.bookAppointment(this.form.value as any).subscribe({
      next: () => {
        this.loading = false;
        this.notifications.success('Appointment booked.');
        this.loadMyAppointments();
      },
      error: () => this.loading = false
    });
  }

  loadMyAppointments(): void {
    this.loading = true;
    this.appointmentsService.getMyAppointments().subscribe({
      next: res => {
        this.data = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  searchById(): void {
    if (!this.searchId) {
      this.notifications.error('Enter appointment ID to search.');
      return;
    }
    this.appointmentsService.searchById(this.searchId).subscribe({
      next: res => {
        this.searchResult = res;
      }
    });
  }
}
