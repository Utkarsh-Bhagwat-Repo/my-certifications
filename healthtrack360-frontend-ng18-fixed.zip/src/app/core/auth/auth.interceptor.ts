import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, catchError, switchMap, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { NotificationService } from '../notification/notification.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private auth: AuthService, private notifications: NotificationService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = this.auth.getAccessToken();

    let authReq = req;
    if (token) {
      authReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }

    return next.handle(authReq).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.status === 401) {
          return this.auth.refreshTokens().pipe(
            switchMap(tokens => {
              if (tokens && tokens.accessToken) {
                const retryReq = req.clone({
                  setHeaders: {
                    Authorization: `Bearer ${tokens.accessToken}`
                  }
                });
                return next.handle(retryReq);
              }
              this.auth.logout();
              this.notifications.error('Session expired. Please login again.');
              return throwError(() => err);
            })
          );
        }

        let message = 'Unexpected error, please try again.';
        if (err.error && typeof err.error === 'object' && err.error.message) {
          message = err.error.message;
        }
        this.notifications.error(message);
        return throwError(() => err);
      })
    );
  }
}
