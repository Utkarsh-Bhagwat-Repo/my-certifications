export interface DoctorResponse {
  id: number;
  fullName: string;
  specialization: string;
  email: string;
  enabled: boolean;
}
