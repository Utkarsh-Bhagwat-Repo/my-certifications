export interface PatientRequest {
  id: number;
  subject: string;
  description: string;
  status: string;
  createdAt: string;
}
