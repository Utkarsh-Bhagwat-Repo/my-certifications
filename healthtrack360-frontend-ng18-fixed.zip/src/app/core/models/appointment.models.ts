export interface Appointment {
  id: number;
  appointmentTime: string;
  status: string;
  doctorName?: string;
  patientName?: string;
}
