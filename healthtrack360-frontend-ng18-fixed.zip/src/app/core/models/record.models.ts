export interface MedicalRecord {
  id: number;
  diagnosis: string;
  notes: string;
  createdAt: string;
}
