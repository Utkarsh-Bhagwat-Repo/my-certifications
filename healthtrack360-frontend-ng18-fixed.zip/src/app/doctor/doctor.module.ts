import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';

import { DoctorRoutingModule } from './doctor-routing.module';
import { DoctorDashboardComponent } from './doctor-dashboard/doctor-dashboard.component';
import { DoctorAppointmentsComponent } from './doctor-appointments/doctor-appointments.component';
import { DoctorPatientsComponent } from './doctor-patients/doctor-patients.component';

@NgModule({
  declarations: [
    DoctorDashboardComponent,
    DoctorAppointmentsComponent,
    DoctorPatientsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    DoctorRoutingModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule
  ]
})
export class DoctorModule {}
