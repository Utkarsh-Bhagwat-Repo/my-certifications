import { Component, OnInit } from '@angular/core';
import { MedicalRecord } from '../../core/models/record.models';
import { RecordsService } from '../../services/records.service';

@Component({
  selector: 'app-patient-records',
  templateUrl: './patient-records.component.html',
  styleUrls: ['./patient-records.component.scss']
})
export class PatientRecordsComponent implements OnInit {
  displayedColumns = ['id', 'diagnosis', 'notes', 'createdAt'];
  data: MedicalRecord[] = [];
  loading = false;

  constructor(private recordsService: RecordsService) {}

  ngOnInit(): void {
    this.loading = true;
    this.recordsService.getMyRecords().subscribe({
      next: res => {
        this.data = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }
}
