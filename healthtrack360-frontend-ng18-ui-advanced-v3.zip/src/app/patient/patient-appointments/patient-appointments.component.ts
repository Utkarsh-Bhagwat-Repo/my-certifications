import { Component, OnInit } from '@angular/core';
import { Appointment } from '../../core/models/appointment.models';
import { AppointmentsService } from '../../services/appointments.service';

@Component({
  selector: 'app-patient-appointments',
  templateUrl: './patient-appointments.component.html',
  styleUrls: ['./patient-appointments.component.scss']
})
export class PatientAppointmentsComponent implements OnInit {
  appointments: Appointment[] = [];
  loading = false;

  constructor(private appointmentsService: AppointmentsService) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.appointmentsService.getMyAppointments().subscribe({
      next: res => {
        this.appointments = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }
}
