import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PatientDashboardComponent } from './patient-dashboard/patient-dashboard.component';
import { PatientAppointmentsComponent } from './patient-appointments/patient-appointments.component';
import { PatientRecordsComponent } from './patient-records/patient-records.component';
import { PatientRequestsComponent } from './patient-requests/patient-requests.component';

const routes: Routes = [
  { path: '', component: PatientDashboardComponent },
  { path: 'appointments', component: PatientAppointmentsComponent },
  { path: 'records', component: PatientRecordsComponent },
  { path: 'requests', component: PatientRequestsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientRoutingModule {}
