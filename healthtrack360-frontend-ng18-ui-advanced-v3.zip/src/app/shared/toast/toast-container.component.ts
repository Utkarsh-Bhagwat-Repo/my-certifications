import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { NotificationService, ToastMessage } from '../../core/notification/notification.service';

@Component({
  selector: 'app-toast-container',
  templateUrl: './toast-container.component.html',
  styleUrls: ['./toast-container.component.scss']
})
export class ToastContainerComponent implements OnInit, OnDestroy {

  toasts: ToastMessage[] = [];
  private sub?: Subscription;

  constructor(private notifications: NotificationService) {}

  ngOnInit(): void {
    this.sub = this.notifications.toasts$.subscribe(toast => {
      this.toasts.push(toast);
      setTimeout(() => {
        this.toasts = this.toasts.filter(t => t !== toast);
      }, toast.duration ?? 3000);
    });
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  dismiss(toast: ToastMessage): void {
    this.toasts = this.toasts.filter(t => t !== toast);
  }
}
