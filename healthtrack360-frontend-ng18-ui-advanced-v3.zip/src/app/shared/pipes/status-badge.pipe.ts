import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'statusBadge' })
export class StatusBadgePipe implements PipeTransform {
  transform(status: string | null | undefined): string {
    if (!status) return '';
    const s = status.toUpperCase();
    if (s === 'APPROVED' || s === 'COMPLETED') return 'badge badge-success';
    if (s === 'REJECTED' || s === 'CANCELLED') return 'badge badge-error';
    return 'badge badge-pending';
  }
}
