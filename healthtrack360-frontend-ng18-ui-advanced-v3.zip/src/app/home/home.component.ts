import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../core/auth/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  constructor(public auth: AuthService, private router: Router) {}

  goToDashboard(): void {
    if (this.auth.hasRole('ROLE_ADMIN')) {
      this.router.navigate(['/admin']);
    } else if (this.auth.hasRole('ROLE_DOCTOR')) {
      this.router.navigate(['/doctor']);
    } else if (this.auth.hasRole('ROLE_PATIENT')) {
      this.router.navigate(['/patient']);
    } else {
      this.router.navigate(['/auth/login']);
    }
  }
}
