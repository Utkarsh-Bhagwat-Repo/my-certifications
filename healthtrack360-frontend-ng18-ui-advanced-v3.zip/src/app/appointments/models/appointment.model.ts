
export type AppointmentStatus = 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'COMPLETED' | 'NO_SHOW';

export interface Appointment {
  id: number;
  doctorId: number;
  doctorName: string;
  patientId: number;
  patientName: string;
  startTime: string; // ISO
  endTime: string;   // ISO
  status: AppointmentStatus;
  specialization: string;
  createdAt: string;
}
