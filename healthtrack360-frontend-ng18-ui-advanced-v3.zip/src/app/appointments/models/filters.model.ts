
export interface AppointmentFilter {
  specialization?: string | null;
  city?: string | null;
  date?: string | null;
  dayOfWeek?: string | null;
  sortBy?: 'RATING' | 'FEE_LOW_TO_HIGH' | 'FEE_HIGH_TO_LOW' | 'EXPERIENCE';
}
