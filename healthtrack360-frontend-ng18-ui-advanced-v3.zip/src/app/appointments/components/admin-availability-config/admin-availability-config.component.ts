import { Component } from '@angular/core';
import { AvailabilityService } from '../../services/availability.service';
import { AvailabilitySlotConfig } from '../../models/availability.model';
import { NotificationService } from '../../../core/notification/notification.service';

@Component({
  selector: 'ht-admin-availability-config',
  templateUrl: './admin-availability-config.component.html',
  styleUrls: ['./admin-availability-config.component.scss']
})
export class AdminAvailabilityConfigComponent {

  doctorId?: number;
  slots: AvailabilitySlotConfig[] = [];
  days = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY'];

  saving = false;

  constructor(
    private availabilityService: AvailabilityService,
    private notifications: NotificationService
  ) {}

  addRow(): void {
    if (!this.doctorId) {
      this.notifications.error('Set a doctor ID before adding slots.');
      return;
    }
    this.slots.push({
      doctorId: this.doctorId,
      dayOfWeek: 'MONDAY',
      startTime: '09:00',
      endTime: '12:00',
      slotDurationMinutes: 15,
      isRecurring: true
    });
  }

  removeRow(index: number): void {
    this.slots.splice(index, 1);
  }

  save(): void {
    if (!this.doctorId) {
      this.notifications.error('Doctor ID is required.');
      return;
    }
    if (this.slots.length === 0) {
      this.notifications.error('Add at least one slot.');
      return;
    }
    // Ensure all slots have doctorId
    this.slots = this.slots.map(s => ({ ...s, doctorId: this.doctorId! }));
    this.saving = true;
    this.availabilityService.saveRecurringSlots(this.slots).subscribe({
      next: () => {
        this.saving = false;
        this.notifications.success('Availability saved successfully.');
      },
      error: () => {
        this.saving = false;
        this.notifications.error('Failed to save availability.');
      }
    });
  }
}
