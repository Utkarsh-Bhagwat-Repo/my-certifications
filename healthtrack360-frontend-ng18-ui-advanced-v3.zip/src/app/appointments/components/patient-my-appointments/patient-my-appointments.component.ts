import { Component, OnInit } from '@angular/core';
import { AppointmentsService } from '../../services/appointments.service';
import { Appointment } from '../../models/appointment.model';
import { NotificationService } from '../../../core/notification/notification.service';

@Component({
  selector: 'ht-patient-my-appointments',
  templateUrl: './patient-my-appointments.component.html',
  styleUrls: ['./patient-my-appointments.component.scss']
})
export class PatientMyAppointmentsComponent implements OnInit {

  appointments: Appointment[] = [];
  loading = false;

  editingAppointment: Appointment | null = null;
  newTime: string = '';
  newConcern: string = '';

  // TODO: replace with actual patientId from auth/user profile
  private readonly patientId = 0;

  constructor(
    private appointmentsService: AppointmentsService,
    private notifications: NotificationService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.appointmentsService.getPatientAppointments(this.patientId).subscribe({
      next: res => {
        this.appointments = res;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        this.notifications.error('Unable to load your appointments.');
      }
    });
  }

  openEdit(appt: Appointment): void {
    this.editingAppointment = appt;
    this.newTime = appt.startTime.substring(0, 16);
    this.newConcern = '';
  }

  cancelEdit(): void {
    this.editingAppointment = null;
  }

  save(): void {
    if (!this.editingAppointment) {
      return;
    }
    const payload: any = {};
    if (this.newTime) {
      payload.startTime = this.newTime;
    }
    if (this.newConcern) {
      payload.concern = this.newConcern;
    }
    if (Object.keys(payload).length === 0) {
      this.notifications.error('Nothing to update.');
      return;
    }

    this.appointmentsService.updateAppointment(this.editingAppointment.id, payload).subscribe({
      next: () => {
        this.notifications.success('Appointment updated successfully.');
        this.editingAppointment = null;
        this.load();
      },
      error: () => {
        this.notifications.error('Failed to update appointment.');
      }
    });
  }

  cancelAppointment(appt: Appointment): void {
    if (!confirm('Are you sure you want to cancel this appointment?')) {
      return;
    }
    this.appointmentsService.cancelAppointment(appt.id).subscribe({
      next: () => {
        this.notifications.success('Appointment cancelled.');
        this.load();
      },
      error: () => {
        this.notifications.error('Failed to cancel appointment.');
      }
    });
  }
}
