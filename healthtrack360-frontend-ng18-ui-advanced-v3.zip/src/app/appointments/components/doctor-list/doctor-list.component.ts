
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Doctor } from '../../models/doctor.model';

@Component({
  selector: 'ht-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.scss']
})
export class DoctorListComponent {

  @Input() doctors: Doctor[] = [];
  @Input() loading = false;
  @Output() selectDoctor = new EventEmitter<Doctor>();

  onSelect(doc: Doctor): void {
    this.selectDoctor.emit(doc);
  }
}
