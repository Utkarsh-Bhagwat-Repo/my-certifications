import { Component, Input, OnChanges } from '@angular/core';
import { Doctor, DoctorAvailabilitySlot } from '../../models/doctor.model';
import { AppointmentsService } from '../../services/appointments.service';
import { NotificationService } from '../../../core/notification/notification.service';

@Component({
  selector: 'ht-doctor-availability-grid',
  templateUrl: './doctor-availability-grid.component.html',
  styleUrls: ['./doctor-availability-grid.component.scss']
})
export class DoctorAvailabilityGridComponent implements OnChanges {

  @Input() doctor!: Doctor;

  days: string[] = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY'];

  loading = false;
  confirmingSlot: DoctorAvailabilitySlot | null = null;
  concern: string = '';

  constructor(
    private appointments: AppointmentsService,
    private notifications: NotificationService
  ) {}

  ngOnChanges(): void {
    // Here we could call availability API; for now we just use doctor.availableSlots
  }

  getSlotsForDay(day: string): DoctorAvailabilitySlot[] {
    return this.doctor?.availableSlots?.filter(s => s.dayOfWeek === day) ?? [];
  }

  openConfirm(slot: DoctorAvailabilitySlot): void {
    this.confirmingSlot = slot;
    this.concern = '';
  }

  cancelDialog(): void {
    this.confirmingSlot = null;
    this.concern = '';
  }

  confirmBooking(): void {
    if (!this.doctor || !this.confirmingSlot) {
      return;
    }
    this.loading = true;

    const payload: any = {
      doctorId: this.doctor.id,
      startTime: this.confirmingSlot.startTime,
      endTime: this.confirmingSlot.endTime,
      concern: this.concern
    };

    this.appointments.bookAppointment(payload).subscribe({
      next: () => {
        this.loading = false;
        this.notifications.success('Appointment booked. Please arrive 10–15 minutes early. Actual consultation may take 30–120 minutes depending on your concern and queue.');
        this.cancelDialog();
      },
      error: () => {
        this.loading = false;
        this.notifications.error('Unable to book appointment. Please try another slot.');
      }
    });
  }
}
