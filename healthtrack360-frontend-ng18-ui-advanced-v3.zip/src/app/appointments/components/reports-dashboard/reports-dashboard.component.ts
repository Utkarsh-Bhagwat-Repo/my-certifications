import { Component, OnInit } from '@angular/core';
import { ChartConfiguration, ChartOptions } from 'chart.js';
import { ReportingService, DailyAppointmentStats, SpecializationStats, DoctorUtilizationStats } from '../../services/reporting.service';

@Component({
  selector: 'ht-reports-dashboard',
  templateUrl: './reports-dashboard.component.html',
  styleUrls: ['./reports-dashboard.component.scss']
})
export class ReportsDashboardComponent implements OnInit {

  fromDate!: string;
  toDate!: string;

  loading = false;

  dailyConfig: ChartConfiguration<'line'>['data'] = { labels: [], datasets: [] };
  specializationConfig: ChartConfiguration<'bar'>['data'] = { labels: [], datasets: [] };
  utilizationConfig: ChartConfiguration<'bar'>['data'] = { labels: [], datasets: [] };

  lineOptions: ChartOptions<'line'> = {
    responsive: true,
    plugins: { legend: { display: true } }
  };

  barOptions: ChartOptions<'bar'> = {
    responsive: true,
    plugins: { legend: { display: true } }
  };

  constructor(private reporting: ReportingService) {}

  ngOnInit(): void {
    const today = new Date();
    const start = new Date();
    start.setDate(today.getDate() - 7);
    this.fromDate = start.toISOString().substring(0, 10);
    this.toDate = today.toISOString().substring(0, 10);
    this.load();
  }

  load(): void {
    if (!this.fromDate || !this.toDate) {
      return;
    }
    this.loading = true;

    this.reporting.getDailyStats(this.fromDate, this.toDate).subscribe({
      next: (daily: DailyAppointmentStats[]) => {
        this.dailyConfig = {
          labels: daily.map(d => d.date),
          datasets: [
            { label: 'Total', data: daily.map(d => d.totalAppointments) },
            { label: 'Completed', data: daily.map(d => d.completed) },
            { label: 'Cancelled', data: daily.map(d => d.cancelled) }
          ]
        };
      },
      error: () => { /* ignore */ }
    });

    this.reporting.getSpecializationStats(this.fromDate, this.toDate).subscribe({
      next: (spec: SpecializationStats[]) => {
        this.specializationConfig = {
          labels: spec.map(s => s.specialization),
          datasets: [
            { label: 'Appointments', data: spec.map(s => s.totalAppointments) }
          ]
        };
      },
      error: () => { /* ignore */ }
    });

    this.reporting.getDoctorUtilization(this.fromDate, this.toDate).subscribe({
      next: (util: DoctorUtilizationStats[]) => {
        this.utilizationConfig = {
          labels: util.map(u => u.doctorName),
          datasets: [
            { label: 'Utilization %', data: util.map(u => u.utilizationPercent) }
          ]
        };
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }
}
