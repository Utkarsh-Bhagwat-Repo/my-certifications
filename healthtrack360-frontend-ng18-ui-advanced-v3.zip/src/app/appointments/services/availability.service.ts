
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AvailabilitySlotConfig } from '../models/availability.model';

@Injectable({ providedIn: 'root' })
export class AvailabilityService {
  private readonly baseUrl = `${environment.apiBaseUrl}/api/v1/availability`;

  constructor(private http: HttpClient) {}

  getDoctorAvailability(doctorId: number, date?: string): Observable<any> {
    let params = new HttpParams();
    if (date) params = params.set('date', date);
    return this.http.get<any>(`${this.baseUrl}/doctor/${doctorId}`, { params });
  }

  saveRecurringSlots(configs: AvailabilitySlotConfig[]): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/recurring`, configs);
  }
}
