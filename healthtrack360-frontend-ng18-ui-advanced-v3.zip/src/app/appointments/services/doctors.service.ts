
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Doctor } from '../models/doctor.model';
import { AppointmentFilter } from '../models/filters.model';

@Injectable({ providedIn: 'root' })
export class DoctorsService {
  private readonly baseUrl = `${environment.apiBaseUrl}/api/v1/doctors`;

  constructor(private http: HttpClient) {}

  getDoctors(filter?: AppointmentFilter): Observable<Doctor[]> {
    let params = new HttpParams();
    if (filter?.specialization) {
      params = params.set('specialization', filter.specialization);
    }
    if (filter?.city) {
      params = params.set('city', filter.city);
    }
    if (filter?.date) {
      params = params.set('date', filter.date);
    }
    if (filter?.dayOfWeek) {
      params = params.set('dayOfWeek', filter.dayOfWeek);
    }
    if (filter?.sortBy) {
      params = params.set('sortBy', filter.sortBy);
    }

    return this.http.get<Doctor[]>(this.baseUrl, { params });
  }

  registerDoctor(payload: any): Observable<Doctor> {
    return this.http.post<Doctor>(this.baseUrl, payload);
  }
}
