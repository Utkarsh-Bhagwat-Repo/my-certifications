import { Component, OnInit } from '@angular/core';
import { PatientResponse } from '../../core/models/patient.models';
import { PatientsService } from '../../services/patients.service';

@Component({
  selector: 'app-doctor-patients',
  templateUrl: './doctor-patients.component.html',
  styleUrls: ['./doctor-patients.component.scss']
})
export class DoctorPatientsComponent implements OnInit {
  patients: PatientResponse[] = [];
  loading = false;

  constructor(private patientsService: PatientsService) {}

  ngOnInit(): void {
    this.loading = true;
    this.patientsService.getAll().subscribe({
      next: res => {
        this.patients = res;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }
}
