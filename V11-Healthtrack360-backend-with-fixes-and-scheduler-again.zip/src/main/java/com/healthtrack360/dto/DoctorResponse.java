package com.healthtrack360.dto;

import com.healthtrack360.domain.Doctor;

public class DoctorResponse {

    private Long id;
    private String fullName;
    private String specialization;
    private Boolean enabled;
    private String email;

    public DoctorResponse() {
    }

    public static DoctorResponse from(Doctor doctor) {
        DoctorResponse dto = new DoctorResponse();
        dto.id = doctor.getId();
        dto.fullName = doctor.getFullName();
        dto.specialization = doctor.getSpecialization();
        if (doctor.getUser() != null) {
            dto.email = doctor.getUser().getEmail();
            dto.enabled = doctor.getUser().isEnabled();
        }
        return dto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
