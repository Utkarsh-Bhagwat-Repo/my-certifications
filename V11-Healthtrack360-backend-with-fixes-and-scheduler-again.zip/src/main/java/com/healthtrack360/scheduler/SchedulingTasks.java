package com.healthtrack360.scheduler;

import com.healthtrack360.domain.Appointment;
import com.healthtrack360.domain.PatientRequest;
import com.healthtrack360.domain.enums.AppointmentStatus;
import com.healthtrack360.domain.enums.RequestStatus;
import com.healthtrack360.repository.AppointmentRepository;
import com.healthtrack360.repository.PatientRequestRepository;
import com.healthtrack360.email.EmailEventProducer;
import com.healthtrack360.email.EmailMessage;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Collections;

/**
 * Scheduled jobs for reminders and housekeeping.
 */
@Component
public class SchedulingTasks {

    private final AppointmentRepository appointmentRepository;
    private final PatientRequestRepository patientRequestRepository;
    private final EmailEventProducer emailEventProducer;

    public SchedulingTasks(AppointmentRepository appointmentRepository,
                           PatientRequestRepository patientRequestRepository,
                           EmailEventProducer emailEventProducer) {
        this.appointmentRepository = appointmentRepository;
        this.patientRequestRepository = patientRequestRepository;
        this.emailEventProducer = emailEventProducer;
    }

    /**
     * Every 15 minutes, send simple reminders for appointments in the next 24 hours.
     */
    @Scheduled(cron = "0 */15 * * * *")
    public void sendUpcomingAppointmentReminders() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime in24Hours = now.plusHours(24);

        List<Appointment> upcoming = appointmentRepository
                .findByStatusAndAppointmentTimeBetween(AppointmentStatus.SCHEDULED, now, in24Hours);

        for (Appointment appt : upcoming) {
            try {
                String subject = "Appointment reminder";
                String body = "Dear " + appt.getPatient().getGivenName()
                        + ", you have an appointment with Dr. "
                        + appt.getDoctor().getFullName()
                        + " at " + appt.getAppointmentTime() + ".";

                EmailMessage emailMessage = new EmailMessage(
                        appt.getPatient().getUser().getEmail(),
                        Collections.emptyList(),
                        subject,
                        body
                );
                emailEventProducer.sendEmailEvent(emailMessage);
            } catch (Exception ex) {
                System.err.println("Failed to send reminder for appointment "
                        + appt.getId() + ": " + ex.getMessage());
            }
        }
    }

    /**
     * Once per night at 02:00, mark pending patient requests older than 48 hours as EXPIRED.
     */
    @Scheduled(cron = "0 0 2 * * *")
    public void expireOldPatientRequests() {
        LocalDateTime cutoff = LocalDateTime.now().minus(48, ChronoUnit.HOURS);

        List<PatientRequest> oldPending = patientRequestRepository
                .findByStatusAndCreatedAtBefore(RequestStatus.PENDING, cutoff);

        for (PatientRequest req : oldPending) {
            req.setStatus(RequestStatus.EXPIRED);
            patientRequestRepository.save(req);

            try {
                String subject = "Your consultation request has expired";
                String body = "Dear " + req.getPatient().getGivenName()
                        + ", your request created on " + req.getCreatedAt()
                        + " has expired because no action was taken in time.";
                EmailMessage emailMessage = new EmailMessage(
                        req.getPatient().getUser().getEmail(),
                        Collections.emptyList(),
                        subject,
                        body
                );
                emailEventProducer.sendEmailEvent(emailMessage);
            } catch (Exception ex) {
                System.err.println("Failed to send expired-request email for request "
                        + req.getId() + ": " + ex.getMessage());
            }
        }
    }
}
